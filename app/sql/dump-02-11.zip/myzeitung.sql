-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 11, 2011 at 06:32 PM
-- Server version: 5.1.37
-- PHP Version: 5.2.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myzeitung`
--

-- --------------------------------------------------------

--
-- Table structure for table `cachekeys`
--

DROP TABLE IF EXISTS `cachekeys`;
CREATE TABLE `cachekeys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL,
  `old_key` varchar(50) NOT NULL DEFAULT '',
  `new_key` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `cachekeys`
--

INSERT INTO `cachekeys` (`id`, `key`, `old_key`, `new_key`) VALUES(6, 'routes', '82d883164fd4f8651768a3e23636f6ae', '82d883164fd4f8651768a3e23636f6ae');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`) VALUES(1, 'admin');
INSERT INTO `groups` (`id`, `name`) VALUES(5, 'scherge');

-- --------------------------------------------------------

--
-- Table structure for table `i18n`
--

DROP TABLE IF EXISTS `i18n`;
CREATE TABLE `i18n` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `locale` varchar(6) NOT NULL,
  `model` varchar(255) NOT NULL,
  `foreign_key` int(10) NOT NULL,
  `field` varchar(255) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `locale` (`locale`),
  KEY `model` (`model`),
  KEY `row_id` (`foreign_key`),
  KEY `field` (`field`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `i18n`
--


-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `topic_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `modified` datetime NOT NULL,
  `created` datetime NOT NULL,
  `enabled` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `count_views` int(11) NOT NULL DEFAULT '0',
  `count_reposts` int(11) NOT NULL DEFAULT '0',
  `count_comments` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`) VALUES(2, 15, 1, 'adfjÃ¶', 'adf', '2011-02-06 16:22:13', '2011-02-06 16:22:13', 1, 0, 0, 0);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`) VALUES(3, 15, 1, 'bb', 'bb', '2011-02-06 16:54:33', '2011-02-06 16:54:33', 1, 0, 0, 0);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`) VALUES(4, 15, 1, 'asdf', 'affdaffe', '2011-02-06 16:59:44', '2011-02-06 16:59:44', 1, 0, 0, 0);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`) VALUES(5, 15, 1, 'asdf', 'asdf', '2011-02-06 17:31:15', '2011-02-06 17:31:15', 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `posts_users`
--

DROP TABLE IF EXISTS `posts_users`;
CREATE TABLE `posts_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `posts_users`
--

INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(1, 15, 5, '2011-02-06 17:31:15');

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

DROP TABLE IF EXISTS `routes`;
CREATE TABLE `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) NOT NULL,
  `target_controller` varchar(100) NOT NULL,
  `target_action` varchar(100) NOT NULL,
  `target_param` varchar(20) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=108 ;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(1, 'admin-5', 'posts', 'view', '2', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(5, 'fasd', 'users', 'view', 'fasd', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(3, 'test-redir', 'users', 'view', '5', 1);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(6, 'alfons', 'users', 'view', '35', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(7, 'ab', 'users', 'view', '36', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(8, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(9, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(10, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(11, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(12, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(13, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(14, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(15, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(16, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(17, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(18, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(19, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(20, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(21, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(22, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(23, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(24, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(25, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(26, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(27, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(28, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(29, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(30, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(31, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(32, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(33, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(34, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(35, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(36, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(37, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(38, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(39, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(40, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(41, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(42, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(43, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(44, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(45, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(46, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(47, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(48, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(49, 'dds33sf', 'users', 'view', '38', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(50, 'dds33sffa', 'users', 'view', '', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(51, 'dds33sffaf', 'users', 'view', '41', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(52, 'jkl', 'users', 'view', '42', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(53, 'jklf3343', 'users', 'view', '43', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(54, 'jklf3343df', 'users', 'view', '44', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(55, 'sebastian', 'users', 'view', '45', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(56, 'sebastian1', 'users', 'view', '46', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(57, 'fffff', 'users', 'view', '47', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(58, 'fffffs', 'users', 'view', '48', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(59, 'fffffse', 'users', 'view', '49', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(60, 'ffd33111', 'users', 'view', '50', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(61, 'ffd3311d1', 'users', 'view', '51', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(62, '345ffd3311d1', 'users', 'view', '52', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(63, 's345ffd3311d1', 'users', 'view', '53', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(64, 's345ffd3311d1d', 'users', 'view', '54', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(65, 'sadsf345ffd3311d1d', 'users', 'view', '55', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(66, 'fdsadsf345ffd3311d1d', 'users', 'view', '56', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(67, 'fdfdsadsf345ffd3311d1d', 'users', 'view', '57', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(68, 'ffdfdsadsf345ffd3311d1d', 'users', 'view', '58', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(69, 'dffdfdsadsf345ffd3311d1d', 'users', 'view', '59', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(70, 'dffdfdsadsf345ffd331f1d1d', 'users', 'view', '60', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(71, 'fdffdfdsadsf345ffd331f1d1d', 'users', 'view', '61', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(72, 'fdffdfdsadsf345ffd331fasdf1d1d', 'users', 'view', '62', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(73, 'ffdffdfdsadsf345ffd331fasdf1d1d', 'users', 'view', '63', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(74, 'asdffff', 'users', 'view', '64', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(75, 'rrr', 'users', 'view', '65', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(76, 'asdfjj', 'users', 'view', '66', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(77, 'jkjkj999', 'users', 'view', '67', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(78, 'jklfasd', 'users', 'view', '68', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(79, 'jlklkj334', 'users', 'view', '69', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(80, 'jasdflklkj334', 'users', 'view', '70', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(81, 'jlkjljj', 'users', 'view', '71', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(82, 'jlkjljjf', 'users', 'view', '72', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(83, 'jlkjljjfd', 'users', 'view', '73', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(84, 'jlkjljjfdd', 'users', 'view', '74', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(85, 'djlkjljjfdd', 'users', 'view', '75', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(86, 'djlkjljjfddd', 'users', 'view', '76', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(87, 'dfdjlkjljjfddd', 'users', 'view', '77', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(88, 'dfdfdjlkjljjfddd', 'users', 'view', '78', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(89, 'fdfdfdjlkjljjfddd', 'users', 'view', '79', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(90, 'fdfdfdjlljjfddd', 'users', 'view', '80', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(91, 'fdfdfdjlljjfdddf', 'users', 'view', '81', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(92, 'jlkjlll', 'users', 'view', '82', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(93, 'jlkj99', 'users', 'view', '83', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(94, 'lasdjf', 'users', 'view', '84', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(95, 'lasdjfasdf', 'users', 'view', '85', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(96, 'lasdjasdfasdf', 'users', 'view', '86', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(97, 'jkjl3e', 'users', 'view', '87', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(98, 'asdfjlkj', 'users', 'view', '88', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(99, 'fdfaasdfjlkj', 'users', 'view', '89', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(100, 'fdfaasdfjlkasfddfj', 'users', 'view', '90', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(101, 'ffdfffaasdfjlkasfddfj', 'users', 'view', '91', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(102, 'zzzzzz', 'users', 'view', '92', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(103, 'zzzzz', 'users', 'view', '', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(104, 'zzzzz', 'users', 'view', '', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(105, 'alfons-hier', 'users', 'view', '93', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(106, 'qqqqqq', 'users', 'view', '94', 0);
INSERT INTO `routes` (`id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(107, 'tim', 'users', 'view', '95', 0);

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
CREATE TABLE `topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `enabled` tinyint(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(1, 'erstes topic', 7, '2011-02-05 13:55:20', '2011-02-05 13:55:20', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(2, 'test_topi', 14, '2011-02-06 14:00:58', '2011-02-06 14:00:58', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(3, 'test_topi', 15, '2011-02-06 14:04:52', '2011-02-06 14:04:52', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(4, 'test_topi', 18, '2011-02-06 23:03:59', '2011-02-06 23:03:59', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(5, 'test_topi', 24, '2011-02-06 23:26:46', '2011-02-06 23:26:46', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(6, 'test_topi', 28, '2011-02-06 23:39:07', '2011-02-06 23:39:07', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(7, 'test_topi', 29, '2011-02-06 23:40:19', '2011-02-06 23:40:19', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(8, 'test_topi', 30, '2011-02-06 23:40:56', '2011-02-06 23:40:56', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(9, 'test_topi', 31, '2011-02-06 23:41:27', '2011-02-06 23:41:27', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(10, 'test_topi', 32, '2011-02-06 23:46:37', '2011-02-06 23:46:37', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(11, 'test_topi', 33, '2011-02-06 23:46:55', '2011-02-06 23:46:55', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(12, 'test_topi', 34, '2011-02-06 23:47:18', '2011-02-06 23:47:18', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(13, 'test_topi', 35, '2011-02-06 23:48:17', '2011-02-06 23:48:17', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(14, 'test_topi', 36, '2011-02-07 19:27:56', '2011-02-07 19:27:56', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(15, 'test_topi', 39, '2011-02-07 19:39:10', '2011-02-07 19:39:10', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(16, 'test_topi', 40, '2011-02-07 19:40:01', '2011-02-07 19:40:01', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(17, 'test_topi', 41, '2011-02-07 19:40:26', '2011-02-07 19:40:26', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(18, 'test_topi', 42, '2011-02-07 19:41:31', '2011-02-07 19:41:31', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(19, 'test_topi', 43, '2011-02-07 19:43:44', '2011-02-07 19:43:44', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(20, 'test_topi', 44, '2011-02-07 19:43:52', '2011-02-07 19:43:52', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(21, 'test_topi', 45, '2011-02-07 19:48:21', '2011-02-07 19:48:21', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(22, 'test_topi', 46, '2011-02-07 23:31:38', '2011-02-07 23:31:38', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(23, 'test_topi', 47, '2011-02-07 23:37:50', '2011-02-07 23:37:50', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(24, 'test_topi', 48, '2011-02-07 23:39:02', '2011-02-07 23:39:02', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(25, 'test_topi', 49, '2011-02-07 23:42:19', '2011-02-07 23:42:19', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(26, 'test_topi', 50, '2011-02-07 23:43:27', '2011-02-07 23:43:27', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(27, 'test_topi', 51, '2011-02-07 23:43:48', '2011-02-07 23:43:48', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(28, 'test_topi', 52, '2011-02-07 23:45:24', '2011-02-07 23:45:24', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(29, 'test_topi', 53, '2011-02-07 23:45:44', '2011-02-07 23:45:44', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(30, 'test_topi', 54, '2011-02-07 23:48:07', '2011-02-07 23:48:07', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(31, 'test_topi', 55, '2011-02-07 23:49:05', '2011-02-07 23:49:05', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(32, 'test_topi', 56, '2011-02-07 23:49:29', '2011-02-07 23:49:29', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(33, 'test_topi', 57, '2011-02-07 23:49:44', '2011-02-07 23:49:44', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(34, 'test_topi', 58, '2011-02-07 23:51:01', '2011-02-07 23:51:01', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(35, 'test_topi', 59, '2011-02-07 23:54:02', '2011-02-07 23:54:02', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(36, 'test_topi', 60, '2011-02-07 23:54:16', '2011-02-07 23:54:16', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(37, 'test_topi', 61, '2011-02-07 23:55:41', '2011-02-07 23:55:41', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(38, 'test_topi', 62, '2011-02-07 23:56:40', '2011-02-07 23:56:40', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(39, 'test_topi', 63, '2011-02-07 23:56:57', '2011-02-07 23:56:57', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(40, 'test_topi', 64, '2011-02-07 23:57:36', '2011-02-07 23:57:36', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(41, 'test_topi', 65, '2011-02-08 00:00:40', '2011-02-08 00:00:40', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(42, 'test_topi', 66, '2011-02-08 00:03:55', '2011-02-08 00:03:55', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(43, 'test_topi', 67, '2011-02-08 00:05:10', '2011-02-08 00:05:10', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(44, 'test_topi', 68, '2011-02-08 00:05:42', '2011-02-08 00:05:42', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(45, 'test_topi', 69, '2011-02-08 00:06:11', '2011-02-08 00:06:11', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(46, 'test_topi', 70, '2011-02-08 00:09:30', '2011-02-08 00:09:30', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(47, 'test_topi', 71, '2011-02-08 19:46:13', '2011-02-08 19:46:13', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(48, 'test_topi', 72, '2011-02-08 19:47:16', '2011-02-08 19:47:16', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(49, 'test_topi', 73, '2011-02-08 19:58:29', '2011-02-08 19:58:29', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(50, 'test_topi', 74, '2011-02-08 20:00:00', '2011-02-08 20:00:00', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(51, 'test_topi', 75, '2011-02-08 20:00:19', '2011-02-08 20:00:19', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(52, 'test_topi', 76, '2011-02-08 20:03:13', '2011-02-08 20:03:13', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(53, 'test_topi', 77, '2011-02-08 20:50:02', '2011-02-08 20:50:02', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(54, 'test_topi', 78, '2011-02-08 20:50:36', '2011-02-08 20:50:36', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(55, 'test_topi', 79, '2011-02-08 20:53:43', '2011-02-08 20:53:43', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(56, 'test_topi', 80, '2011-02-08 20:58:51', '2011-02-08 20:58:51', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(57, 'test_topi', 81, '2011-02-08 20:59:23', '2011-02-08 20:59:23', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(58, 'test_topi', 82, '2011-02-08 20:59:51', '2011-02-08 20:59:51', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(59, 'test_topi', 83, '2011-02-08 21:00:24', '2011-02-08 21:00:24', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(60, 'test_topi', 84, '2011-02-08 21:38:30', '2011-02-08 21:38:30', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(61, 'test_topi', 85, '2011-02-08 21:53:20', '2011-02-08 21:53:20', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(62, 'test_topi', 86, '2011-02-08 21:53:36', '2011-02-08 21:53:36', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(63, 'test_topi', 87, '2011-02-08 22:02:12', '2011-02-08 22:02:12', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(64, 'test_topi', 88, '2011-02-08 22:06:09', '2011-02-08 22:06:09', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(65, 'test_topi', 89, '2011-02-08 22:06:32', '2011-02-08 22:06:32', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(66, 'test_topi', 90, '2011-02-08 22:06:52', '2011-02-08 22:06:52', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(67, 'test_topi', 91, '2011-02-08 22:07:56', '2011-02-08 22:07:56', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(68, 'test_topi', 92, '2011-02-08 22:09:27', '2011-02-08 22:09:27', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(69, 'test_topi', 93, '2011-02-10 22:24:13', '2011-02-10 22:24:13', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(70, 'test_topi', 94, '2011-02-10 22:31:53', '2011-02-10 22:31:53', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(71, 'test_topi', 95, '2011-02-11 18:27:36', '2011-02-11 18:27:36', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `enabled` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=96 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(5, 1, 0, 'admin', 'admin', 'admin@admin.de', 'admin', 'admin', '2011-02-05 12:29:42', '2011-02-05 22:16:05', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(6, 0, 0, '', '', 'penis@penis.de', 'penis', 'penis', '2011-02-05 13:19:46', '2011-02-05 13:26:00', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(7, 5, 0, '', '', 'hans@hans.de', 'hans', 'f10e739b1acbbd77a09d8d06454eaeb59b5c8389', '2011-02-05 13:26:18', '2011-02-06 12:00:53', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(95, 1, 107, 'tim', 'tim', 'tim@tim.de', 'tim', '89fc872d377a62ba2e75bbd1d630eb790ee687f9', '2011-02-11 18:27:36', '2011-02-11 18:27:36', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(9, 0, 0, '', '', 'bla@bla.de', 'bla', 'aada2dd8e498e893a0646d0044e95af95bea64b3', '2011-02-05 13:30:48', '2011-02-05 13:30:48', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(10, 0, 0, 'asdf', 'adsff', 'asdf@ad.de', 'asdf', 'd115d8676b21f94291f759d9e3f74988e36fa512', '2011-02-05 22:03:42', '2011-02-05 22:03:42', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(11, 1, 0, 'sdf', 'sdf', 'asdf@asdf.de', 'asdfasdf', 'd115d8676b21f94291f759d9e3f74988e36fa512', '2011-02-05 22:05:29', '2011-02-05 22:05:29', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(12, 5, 0, 'karl', 'ranseier', 'karl@asd.de', 'karl', '23724d601ca463f4dd94656c783578d39cd9bc45', '2011-02-05 22:29:36', '2011-02-05 22:29:59', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(13, 1, 0, '', '', 'bla@bla.de', 'rans', 'c05c0aed238a12e8e8bc4289485aa39f99542bea', '2011-02-06 12:41:52', '2011-02-06 12:41:52', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(14, 1, 0, 'fffadsf', 'asdfsadf', 'sonntag@sonntag.de', 'sdf', '3cc4e8f13e5ecd5df8be86668b325c3ecc361bf9', '2011-02-06 14:00:58', '2011-02-06 14:00:58', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(15, 1, 0, 'adsf', 'asdf', 'aaa@aaa.de', 'aaaaaaaa', '531a323e24c9d2f38811886cdea06021757d67f0', '2011-02-06 14:04:52', '2011-02-06 14:04:52', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(16, 1, 0, 'bb', 'bb', 'tt@ads.de', 'bbbbbbbb', '2f7435f4560c10f57fd10db8e11974ddedfe23b4', '2011-02-06 22:55:11', '2011-02-06 22:55:11', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(17, 1, 0, 'bb', 'bb', 'tt@ads.de', 'cccccccc', '1273df84c142583b3fbca046438ff485a032e0ce', '2011-02-06 23:00:22', '2011-02-06 23:00:22', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(18, 1, 0, 'bb', 'bb', 'tt@ads.de', 'dddddddd', 'c3366fd3cf8dc18a1029acc19dab3cd102424c97', '2011-02-06 23:03:59', '2011-02-06 23:03:59', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(19, 1, 0, 'bb', 'bb', 'tt@ads.de', 'eeeeeeee', '6ca0a74602207191551b6eeef6c1ae713eb34895', '2011-02-06 23:06:05', '2011-02-06 23:06:05', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(20, 1, 0, 'bb', 'bb', 'tt@ads.de', 'ffff', '0b98b50c281a67f60d57858a8b867eb085cbb5eb', '2011-02-06 23:07:08', '2011-02-06 23:07:08', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(21, 1, 0, 'bb', 'bb', 'tt@ads.de', 'ggggg', '6509cebe29712224efd9b51642202ee5cf741c8c', '2011-02-06 23:09:10', '2011-02-06 23:09:10', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(22, 1, 0, 'bb', 'bb', 'tt@ads.de', 'hhhhh', 'a9f2e2d9f6b0541df73f57f690836f6ccfb22736', '2011-02-06 23:09:42', '2011-02-06 23:09:42', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(23, 1, 0, 'bb', 'bb', 'tt@ads.de', 'iiiii', '5f63854d45c19d58cd0ead950e9cba51ec1384e6', '2011-02-06 23:20:19', '2011-02-06 23:20:19', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(24, 1, 0, 'bb', 'bb', 'tt@ads.de', 'kkkkk', 'd2b88d94d9ebbb92ff6f0774a6c8c43702de6dd1', '2011-02-06 23:26:46', '2011-02-06 23:26:46', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(25, 1, 0, 'zzzzz', 'zzzzz', 'ere@dd.ed', 'zzzzz', 'a803a8e1a734d87c2835ea3753647589b1e10855', '2011-02-06 23:36:59', '2011-02-06 23:36:59', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(26, 1, 0, 'zzzzz', 'zzzzz', 'ere@dd.ed', 'fasdfes3', 'd115d8676b21f94291f759d9e3f74988e36fa512', '2011-02-06 23:37:20', '2011-02-06 23:37:20', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(27, 1, 0, 'zzzzz', 'zzzzz', 'ere@dd.ed', 'fasdfes3ffadf', '8f17e60db441e7441a04d03d2a61b98d4fab4073', '2011-02-06 23:37:48', '2011-02-06 23:37:48', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(28, 1, 0, 'zzzzz', 'zzzzz', 'ere@dd.ed', 'fasd', '957172f936c51e7be7355895e3f45585c3e43961', '2011-02-06 23:39:07', '2011-02-06 23:39:07', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(29, 1, 0, 'jj', 'jj', 'erwer@df.dw', 'sdafjj', 'c28508776ec32151bb0ec6447d3762c98df2af95', '2011-02-06 23:40:19', '2011-02-06 23:40:19', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(30, 1, 0, 'jj', 'jj', 'erwer@df.dw', 'ffadsfadfee', '1f53c7a6bd31fb30674db990930925cf79be0fba', '2011-02-06 23:40:55', '2011-02-06 23:40:55', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(31, 1, 0, 'jj', 'jj', 'erwer@df.dw', 'ffadsfadfee45', '3748f1e6281561f61c74ac111655e2e3930c7555', '2011-02-06 23:41:27', '2011-02-06 23:41:27', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(32, 1, 0, 'jj', 'jj', 'erwer@df.dw', '11ffadsfadfee45', '92770e1e977e9680f5a97e058e9064c74515819f', '2011-02-06 23:46:37', '2011-02-06 23:46:37', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(33, 1, 0, 'jj', 'jj', 'erwer@df.dw', '11155', '3d4aa34ce7ad35d85acd8d2da76fa86db93ac905', '2011-02-06 23:46:50', '2011-02-06 23:46:50', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(34, 1, 0, 'jj', 'jj', 'erwer@df.dw', '1452', '57b74cd4988aa05ebb77aedfee2bc5ba4f68b634', '2011-02-06 23:47:18', '2011-02-06 23:47:18', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(35, 1, 0, '8888888', '88888888', 'ffferwer@df.dw', 'alfons', 'ccbd4ab63c31526bec99c55d8696b3fad0d85997', '2011-02-06 23:48:17', '2011-02-06 23:48:17', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(36, 1, 0, 'ab', 'b', 'ab@ab.de', 'ab', '68b4ae28d3e49c40d7a03e1101fe3257e75aa540', '2011-02-07 19:27:56', '2011-02-07 19:27:56', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(37, 1, 0, 'asdf', 'asdf', 'cc@ads.dd', 'asdfffasdf', 'cc5b05e20e56d983dbc94937655d1bf1cb17c8ca', '2011-02-07 19:31:37', '2011-02-07 19:31:37', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(38, 1, 0, 'asdf', 'asdf', 'cc@adsd.dd', 'dds33sf', 'e14261368c993ffc282a22cadb25067cb3a547e9', '2011-02-07 19:33:23', '2011-02-07 19:33:23', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(39, 1, 0, 'asdf', 'asdf', 'cc@adsd.dd', 'dds33sff', '9d62b9766a05717b548e08ec9b9b92199bb910e4', '2011-02-07 19:39:10', '2011-02-07 19:39:10', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(40, 1, 0, 'asdf', 'asdf', 'cc@adsd.dd', 'dds33sffa', 'f5fb7259065e818eb589d1022c384c0bd39bdb67', '2011-02-07 19:40:01', '2011-02-07 19:40:01', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(41, 1, 0, 'asdf', 'asdf', 'cc@adsd.dd', 'dds33sffaf', 'c733f1a4aaad85aa40b6557059d7703a16d48865', '2011-02-07 19:40:26', '2011-02-07 19:40:26', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(42, 1, 0, 'ljk', 'lj', 'asdf@adsf.de', 'jkl', '66088154ae429f098a3094408b9b1cd7b648f2a8', '2011-02-07 19:41:31', '2011-02-07 19:41:31', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(43, 1, 0, 'ljk', 'lj', 'asdf@adsf.de', 'jklf3343', '534132b3b04b78a6f95074fa8c525bf7c57dd529', '2011-02-07 19:43:44', '2011-02-07 19:43:44', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(44, 1, 54, 'ljk', 'lj', 'asdf@adsf.de', 'jklf3343df', '7a8737e4d4afc593035eb399531bd6011ac411d0', '2011-02-07 19:43:52', '2011-02-07 19:43:52', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(45, 1, 55, 'test', 'test', 'sebastian.alfers@gmail.com', 'sebastian', 'af7198863c06c0f361ff873071c4cb815026743f', '2011-02-07 19:48:21', '2011-02-07 19:48:21', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(46, 1, 56, 'asdf', 'sdfds', 'wrwerls@asdf.de', 'sebastian1', '200af8ae92410735bdc2a96c4ca26eb7a7d853f9', '2011-02-07 23:31:37', '2011-02-07 23:31:38', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(47, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'fffff', '51d8d8c9235149908207d4af1b29e2e0ee4b106f', '2011-02-07 23:37:50', '2011-02-07 23:37:50', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(48, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'fffffs', '83a61c23ef591ad68972bd30abe68f11ff092f63', '2011-02-07 23:39:02', '2011-02-07 23:39:02', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(49, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'fffffse', '92052b1d956517881c8d88236b30f54cf546a8fe', '2011-02-07 23:42:19', '2011-02-07 23:42:19', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(50, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'ffd33111', '59eaee8f91cee58fcacafc3267c748301deb2305', '2011-02-07 23:43:27', '2011-02-07 23:43:27', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(51, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'ffd3311d1', 'd6ee8fadda51f758a41994b4c2ba449e5f626cdd', '2011-02-07 23:43:48', '2011-02-07 23:43:48', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(52, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', '345ffd3311d1', 'd0d3023a8ab6b1629f7b2d60508163984c124e64', '2011-02-07 23:45:24', '2011-02-07 23:45:24', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(53, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 's345ffd3311d1', '001b5fd13bc2ec9c0969cb04653548ac52530478', '2011-02-07 23:45:44', '2011-02-07 23:45:44', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(54, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 's345ffd3311d1d', '66f051e10a422cbfa99fb9392cb53918d7c6623e', '2011-02-07 23:48:07', '2011-02-07 23:48:07', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(55, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'sadsf345ffd3311d1d', 'f065b97afd6d20bec15238a27efefa6ca6b36c1c', '2011-02-07 23:49:05', '2011-02-07 23:49:05', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(56, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'fdsadsf345ffd3311d1d', 'bd32604777077e1e6e564980786d9a396d3535f3', '2011-02-07 23:49:29', '2011-02-07 23:49:29', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(57, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'fdfdsadsf345ffd3311d1d', '8c3c57ab17bc4c959f58338bf3e06ae29227fac7', '2011-02-07 23:49:44', '2011-02-07 23:49:44', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(58, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'ffdfdsadsf345ffd3311d1d', '06cb452e9fea064330325b6ab137f014002aa12a', '2011-02-07 23:51:01', '2011-02-07 23:51:01', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(59, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'dffdfdsadsf345ffd3311d1d', '61d31ae39d7110e2e47c999a31c4db0cee18f3f1', '2011-02-07 23:54:02', '2011-02-07 23:54:02', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(60, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'dffdfdsadsf345ffd331f1d1d', 'e54886b3526c364b5bde3e09928a8774b8067eaa', '2011-02-07 23:54:16', '2011-02-07 23:54:16', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(61, 1, 0, 'fffff', 'ff', 'ASDF@adfff.de', 'fdffdfdsadsf345ffd331f1d1d', '9028b60f3a44898ee9e6daa4387120ead9da6056', '2011-02-07 23:55:41', '2011-02-07 23:55:41', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(62, 1, 72, 'fffff', 'ff', 'ASDF@adfff.de', 'fdffdfdsadsf345ffd331fasdf1d1d', '615cc8fdd4e76387a01783b059b3100051687fb0', '2011-02-07 23:56:40', '2011-02-07 23:56:40', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(63, 1, 73, 'fffff', 'ff', 'ASDF@adfff.de', 'ffdffdfdsadsf345ffd331fasdf1d1d', '1c549823466989c9f45bd9a101c70e97802714d2', '2011-02-07 23:56:57', '2011-02-07 23:56:57', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(64, 1, 74, 'asdf', 'asdf', 'asdflkjl@asd.de', 'asdffff', 'ab2695c7393efc954fb62532659f362cc0b369de', '2011-02-07 23:57:36', '2011-02-07 23:57:36', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(65, 1, 75, 'ljk', 'kj', 'jkf@dd.de', 'rrr', '4dc6cbf0662e50762ade5e51982976a753feac24', '2011-02-08 00:00:40', '2011-02-08 00:00:40', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(66, 1, 76, 'jk', 'l', 'fasd@asdf.de', 'asdfjj', 'd115d8676b21f94291f759d9e3f74988e36fa512', '2011-02-08 00:03:55', '2011-02-08 00:03:55', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(67, 1, 77, 'jlk', '', 'uur@dd.de', 'jkjkj999', '2783259a4ac0135a2cdbccb042b2c07e67cc483f', '2011-02-08 00:05:10', '2011-02-08 00:05:10', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(68, 1, 78, '', 'l', '234e@df.de', 'jklfasd', 'cf18575154077cd4049a3881e8d42556c17dff05', '2011-02-08 00:05:42', '2011-02-08 00:05:42', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(69, 1, 79, '', '', 'uio@asdf.de', 'jlklkj334', 'd115d8676b21f94291f759d9e3f74988e36fa512', '2011-02-08 00:06:11', '2011-02-08 00:06:11', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(70, 1, 0, '', '', 'uio@asdf.de', 'jasdflklkj334', 'cc5b05e20e56d983dbc94937655d1bf1cb17c8ca', '2011-02-08 00:09:30', '2011-02-08 00:09:30', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(71, 1, 0, 'lkj', 'jl', 'wer@adff.de', 'jlkjljj', 'd115d8676b21f94291f759d9e3f74988e36fa512', '2011-02-08 19:46:13', '2011-02-08 19:46:13', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(72, 1, 0, 'lkj', 'jl', 'wer@adff.de', 'jlkjljjf', 'cc5b05e20e56d983dbc94937655d1bf1cb17c8ca', '2011-02-08 19:47:16', '2011-02-08 19:47:16', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(73, 1, 0, 'lkj', 'jl', 'wer@adff.de', 'jlkjljjfd', 'e14261368c993ffc282a22cadb25067cb3a547e9', '2011-02-08 19:58:29', '2011-02-08 19:58:29', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(74, 1, 0, 'lkj', 'jl', 'wer@adff.de', 'jlkjljjfdd', '9d62b9766a05717b548e08ec9b9b92199bb910e4', '2011-02-08 20:00:00', '2011-02-08 20:00:00', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(75, 1, 0, 'lkj', 'jl', 'wer@adff.de', 'djlkjljjfdd', 'f5fb7259065e818eb589d1022c384c0bd39bdb67', '2011-02-08 20:00:19', '2011-02-08 20:00:19', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(76, 1, 0, 'lkj', 'jl', 'wer@adff.de', 'djlkjljjfddd', 'c733f1a4aaad85aa40b6557059d7703a16d48865', '2011-02-08 20:03:13', '2011-02-08 20:03:13', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(77, 1, 0, 'lkj', 'jl', 'wer@adff.de', 'dfdjlkjljjfddd', '89b90b637f43897e0c897e43fedf83e828782935', '2011-02-08 20:50:02', '2011-02-08 20:50:02', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(78, 1, 88, 'lkj', 'jl', 'wer@adff.de', 'dfdfdjlkjljjfddd', '19c1216fcc8ec643b79f9c1e6b929cb04ca7fba9', '2011-02-08 20:50:36', '2011-02-08 20:50:36', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(79, 1, 89, 'lkj', 'jl', 'wer@adff.de', 'fdfdfdjlkjljjfddd', '274ceccb2fa1c06fba8de0169d3333b968d90f46', '2011-02-08 20:53:43', '2011-02-08 20:53:43', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(80, 1, 90, 'lkj', 'jl', 'wer@adff.de', 'fdfdfdjlljjfddd', '863718622a0b75fb896cd30f35fa7941aede98dc', '2011-02-08 20:58:51', '2011-02-08 20:58:51', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(81, 1, 91, 'lkj', 'jl', 'wer@adff.de', 'fdfdfdjlljjfdddf', '689868878467f2b5dee0f6cf38e982d07f104f2f', '2011-02-08 20:59:23', '2011-02-08 20:59:23', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(82, 1, 92, 'klj', 'lkjl', 'asdf@asdf.com', 'jlkjlll', '6e6b6afd9d488aefe65a884b1a9684d6407fee8b', '2011-02-08 20:59:51', '2011-02-08 20:59:51', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(83, 1, 93, 'lÃ¶k', '', 'safdf@asd.de', 'jlkj99', 'd115d8676b21f94291f759d9e3f74988e36fa512', '2011-02-08 21:00:24', '2011-02-08 21:00:24', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(84, 1, 0, 'lj', 'l', 'asdf@adsf.de', 'lasdjf', 'f8f8dd367a2064e4d44f622bf6abdeadd0e972c0', '2011-02-08 21:38:30', '2011-02-08 21:38:30', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(85, 1, 95, 'lj', 'l', 'asdf@adsf.de', 'lasdjfasdf', 'd96a1a8cf209ef4c388a6fab50181aa620d95207', '2011-02-08 21:53:20', '2011-02-08 21:53:20', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(86, 1, 96, 'lj', 'l', 'asdf@adsf.de', 'lasdjasdfasdf', 'e12f1f3e44c6816ee169a4db2c532a44823adc67', '2011-02-08 21:53:36', '2011-02-08 21:53:36', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(87, 1, 97, 'jkl', 'l', 'sf@ad.de', 'jkjl3e', '8940c0aeb1bf897e14b6d5a04de09aaa7178eafe', '2011-02-08 22:02:12', '2011-02-08 22:02:12', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(88, 1, 98, 'lj', '', 'asfd@fff.de', 'asdfjlkj', '5431766ee02d8bea9a41d44710c7b99551042b5c', '2011-02-08 22:06:09', '2011-02-08 22:06:09', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(89, 1, 0, 'lj', '', 'asfd@fff.de', 'fdfaasdfjlkj', '8d23aad11ef4e44dcebbdd4f216aa1cb813e7f4d', '2011-02-08 22:06:32', '2011-02-08 22:06:32', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(90, 1, 100, 'lj', '', 'asfd@fff.de', 'fdfaasdfjlkasfddfj', 'eb16d72b0ca8ea697d4ff83c504b2ae9e0677ebb', '2011-02-08 22:06:52', '2011-02-08 22:06:52', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(91, 1, 101, 'lj', '', 'asfd@fff.de', 'ffdfffaasdfjlkasfddfj', '42a9aa59616f01031c81a39e6aebbc739da956b2', '2011-02-08 22:07:56', '2011-02-08 22:07:56', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(92, 1, 102, 'z', 'z', 'zzz@zzz.de', 'zzzzzz', '8ad70dd4165ed077b625aa2601e053667459412b', '2011-02-08 22:09:27', '2011-02-08 22:09:27', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(93, 1, 105, 'zzz', 'zz', 'asdf@fff.de', 'alfons-hier//', 'beaf2b4b37b2a43f1780e37a00e4a83cb7c8edd3', '2011-02-10 22:24:13', '2011-02-10 22:24:13', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `route_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(94, 1, 106, 'qq', 'qqq', 'qqq@qqq.de', 'qqqqqq', '30a784dbb7e9ea5182bbc2aa56cf14b84b8ca3ba', '2011-02-10 22:31:53', '2011-02-10 22:31:53', NULL, 1);
