-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 26, 2011 at 05:09 PM
-- Server version: 5.1.37
-- PHP Version: 5.2.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myzeitung`
--

-- --------------------------------------------------------

--
-- Table structure for table `cachekeys`
--

DROP TABLE IF EXISTS `cachekeys`;
CREATE TABLE `cachekeys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL,
  `old_key` varchar(50) NOT NULL,
  `new_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cachekeys`
--


-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `paper_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(1, 0, 1, 'my super category', '2011-02-15 22:28:13', '2011-02-15 22:28:13');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(2, 0, 1, 'nochne category', '2011-02-15 22:29:19', '2011-02-15 22:29:19');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(3, 0, 0, 'aaaaaaaaaaaaaa', '2011-02-15 22:41:29', '2011-02-15 22:41:29');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(4, 0, 0, 'zzzzzzzzzzzzzz', '2011-02-15 22:41:49', '2011-02-15 22:41:49');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(5, 3, 0, 'sub for zzzzzzzzzzzz', '2011-02-15 23:02:47', '2011-02-15 23:02:47');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(6, 1, 0, 'rrrrrrrrrrrrrrrrrr', '2011-02-15 23:04:09', '2011-02-15 23:04:09');

-- --------------------------------------------------------

--
-- Table structure for table `category_paper_posts`
--

DROP TABLE IF EXISTS `category_paper_posts`;
CREATE TABLE `category_paper_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `paper_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `category_paper_posts`
--

INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`) VALUES(5, 86, 2, 0);
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`) VALUES(4, 85, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `content_papers`
--

DROP TABLE IF EXISTS `content_papers`;
CREATE TABLE `content_papers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `topic_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `content_papers`
--

INSERT INTO `content_papers` (`id`, `paper_id`, `category_id`, `user_id`, `topic_id`) VALUES(4, 1, NULL, NULL, 4);
INSERT INTO `content_papers` (`id`, `paper_id`, `category_id`, `user_id`, `topic_id`) VALUES(10, 1, NULL, 1, NULL);
INSERT INTO `content_papers` (`id`, `paper_id`, `category_id`, `user_id`, `topic_id`) VALUES(11, 2, NULL, 1, NULL);
INSERT INTO `content_papers` (`id`, `paper_id`, `category_id`, `user_id`, `topic_id`) VALUES(12, 2, NULL, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `i18n`
--

DROP TABLE IF EXISTS `i18n`;
CREATE TABLE `i18n` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `locale` varchar(6) NOT NULL,
  `model` varchar(255) NOT NULL,
  `foreign_key` int(10) NOT NULL,
  `field` varchar(255) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `locale` (`locale`),
  KEY `model` (`model`),
  KEY `row_id` (`foreign_key`),
  KEY `field` (`field`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `i18n`
--


-- --------------------------------------------------------

--
-- Table structure for table `papers`
--

DROP TABLE IF EXISTS `papers`;
CREATE TABLE `papers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `papers`
--

INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`) VALUES(1, 1, 'alfs paper', 'my paper', '', '2011-02-15 22:20:44', '2011-02-15 22:20:44');
INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`) VALUES(2, 1, 'second paper', 'aaaaaaaaaaaaaaaaaaaaa', '', '2011-02-15 22:41:09', '2011-02-15 22:41:09');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `modified` datetime NOT NULL,
  `created` datetime NOT NULL,
  `enabled` int(3) NOT NULL DEFAULT '1',
  `count_views` int(11) NOT NULL DEFAULT '0',
  `count_reposts` int(11) NOT NULL DEFAULT '0',
  `count_comments` int(11) NOT NULL DEFAULT '0',
  `reposters` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=87 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(1, 1, 2, 'ssecond post', 'second\r\n', '2011-02-16 19:54:52', '2011-02-16 19:54:52', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(2, 1, 1, 'freitaggggggggg_erstessssssssss', 'freitaggggggggg_erstessssssssss', '2011-02-18 13:33:22', '2011-02-18 13:33:22', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(3, 1, 2, 'freitaggggggggg_zzzzzzzzzzzweitessssssss', 'freitaggggggggg_zzzzzzzzzzzweitessssssss', '2011-02-18 13:33:34', '2011-02-18 13:33:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(4, 1, 1, 'after save tset', 'test', '2011-02-18 14:58:25', '2011-02-18 14:58:25', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(5, 1, 1, 'after save tset', 'test', '2011-02-18 15:06:26', '2011-02-18 15:06:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(6, 1, 1, 'after save tset', 'test', '2011-02-18 15:06:42', '2011-02-18 15:06:42', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(7, 1, 1, 'after save tset', 'test', '2011-02-18 15:06:50', '2011-02-18 15:06:50', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(8, 1, 1, 'after save tset', 'test', '2011-02-18 15:07:00', '2011-02-18 15:07:00', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(9, 1, 1, 'after save tset', 'test', '2011-02-18 15:07:55', '2011-02-18 15:07:55', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(10, 1, 1, 'after save tset', 'test', '2011-02-18 15:09:42', '2011-02-18 15:09:42', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(11, 1, 1, 'after save tset', 'test', '2011-02-18 15:09:55', '2011-02-18 15:09:55', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(12, 1, 1, 'after save tset', 'test', '2011-02-18 15:10:03', '2011-02-18 15:10:03', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(13, 1, 1, 'after save tset', 'test', '2011-02-18 15:11:04', '2011-02-18 15:11:04', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(14, 1, 1, 'after save tset', 'test', '2011-02-18 15:11:11', '2011-02-18 15:11:11', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(15, 1, 1, 'after save tset', 'test', '2011-02-18 15:11:24', '2011-02-18 15:11:24', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(16, 1, 1, 'after save tset', 'test', '2011-02-18 15:15:55', '2011-02-18 15:15:55', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(17, 1, 1, 'after save tset', 'test', '2011-02-18 15:16:22', '2011-02-18 15:16:22', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(18, 1, 1, 'after save tset', 'test', '2011-02-18 15:19:13', '2011-02-18 15:19:13', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(19, 1, 1, 'after save tset', 'test', '2011-02-18 15:20:11', '2011-02-18 15:20:11', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(20, 1, 1, 'after save tset', 'test', '2011-02-18 15:20:21', '2011-02-18 15:20:21', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(21, 1, 1, 'after save tset', 'test', '2011-02-18 15:21:49', '2011-02-18 15:21:49', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(22, 1, 1, 'after save tset', 'test', '2011-02-18 15:21:56', '2011-02-18 15:21:56', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(23, 1, 1, 'after save tset', 'test', '2011-02-18 15:22:44', '2011-02-18 15:22:44', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(24, 1, 1, 'after save tset', 'test', '2011-02-18 15:22:52', '2011-02-18 15:22:52', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(25, 1, 1, 'after save tset', 'test', '2011-02-18 15:24:30', '2011-02-18 15:24:30', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(26, 1, 1, 'after save tset', 'test', '2011-02-18 15:24:34', '2011-02-18 15:24:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(27, 1, 1, 'after save tset', 'test', '2011-02-18 15:24:39', '2011-02-18 15:24:39', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(28, 1, 1, 'after save tset', 'test', '2011-02-18 15:26:26', '2011-02-18 15:26:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(29, 1, 1, 'after save tset', 'test', '2011-02-18 15:26:52', '2011-02-18 15:26:52', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(30, 1, 1, 'after save tset', 'test', '2011-02-18 15:27:04', '2011-02-18 15:27:04', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(31, 1, 1, 'after save tset', 'test', '2011-02-18 15:27:56', '2011-02-18 15:27:56', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(32, 1, 1, 'after save tset', 'test', '2011-02-18 15:33:10', '2011-02-18 15:33:10', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(33, 1, 1, 'after save tset', 'test', '2011-02-18 15:35:01', '2011-02-18 15:35:01', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(34, 1, 1, 'after save tset', 'test', '2011-02-18 15:35:50', '2011-02-18 15:35:50', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(35, 1, 1, 'after save tset', 'test', '2011-02-18 15:36:13', '2011-02-18 15:36:13', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(36, 1, 1, 'after save tset', 'test', '2011-02-18 15:38:07', '2011-02-18 15:38:07', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(37, 1, 1, 'after save tset', 'test', '2011-02-18 15:39:37', '2011-02-18 15:39:37', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(38, 1, 1, 'after save tset', 'test', '2011-02-18 15:39:46', '2011-02-18 15:39:46', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(39, 1, 1, 'after save tset', 'test', '2011-02-18 15:39:57', '2011-02-18 15:39:57', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(40, 1, 1, 'after save tset', 'test', '2011-02-18 15:41:10', '2011-02-18 15:41:10', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(41, 1, 1, 'after save tset', 'test', '2011-02-18 15:41:29', '2011-02-18 15:41:29', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(42, 1, 1, 'after save tset', 'test', '2011-02-18 15:47:29', '2011-02-18 15:47:29', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(43, 1, 1, 'after save tset', 'test', '2011-02-18 16:00:06', '2011-02-18 16:00:06', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(44, 1, 1, 'after save tset', 'test', '2011-02-18 16:07:03', '2011-02-18 16:07:03', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(45, 1, 1, 'after save tset', 'test', '2011-02-18 16:07:05', '2011-02-18 16:07:05', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(46, 1, 1, 'after save tset', 'test', '2011-02-18 16:08:26', '2011-02-18 16:08:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(47, 1, 1, 'after save tset', 'test', '2011-02-18 16:08:32', '2011-02-18 16:08:32', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(48, 1, 1, 'after save tset', 'test', '2011-02-18 16:23:41', '2011-02-18 16:23:41', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(49, 1, 1, 'after save tset', 'test', '2011-02-18 16:25:23', '2011-02-18 16:25:23', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(50, 1, 1, 'after save tset', 'test', '2011-02-18 16:26:19', '2011-02-18 16:26:19', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(51, 1, 1, 'after save tset', 'test', '2011-02-18 16:27:30', '2011-02-18 16:27:30', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(52, 1, 1, 'after save tset', 'test', '2011-02-18 16:27:41', '2011-02-18 16:27:41', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(53, 1, 1, 'after save tset', 'test', '2011-02-18 16:28:05', '2011-02-18 16:28:05', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(54, 1, 1, 'after save tset', 'test', '2011-02-18 16:28:15', '2011-02-18 16:28:15', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(55, 1, 1, 'after save tset', 'test', '2011-02-18 16:28:49', '2011-02-18 16:28:49', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(56, 1, 1, 'after save tset', 'test', '2011-02-18 16:29:04', '2011-02-18 16:29:04', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(57, 1, 1, 'after save tset', 'test', '2011-02-18 16:30:20', '2011-02-18 16:30:20', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(58, 1, 1, 'after save tset', 'test', '2011-02-18 16:30:28', '2011-02-18 16:30:28', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(59, 1, 1, 'after save tset', 'test', '2011-02-18 16:30:54', '2011-02-18 16:30:54', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(60, 1, 1, 'after save tset', 'test', '2011-02-18 16:31:04', '2011-02-18 16:31:04', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(61, 1, 1, 'after save tset', 'test', '2011-02-18 16:31:48', '2011-02-18 16:31:48', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(62, 1, 1, 'after save tset', 'test', '2011-02-18 16:37:42', '2011-02-18 16:37:42', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(63, 1, 1, 'after save tset', 'test', '2011-02-18 16:40:02', '2011-02-18 16:40:02', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(64, 1, 1, 'after save tset', 'test', '2011-02-18 16:40:26', '2011-02-18 16:40:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(65, 1, 1, 'after save tset', 'test', '2011-02-18 16:41:17', '2011-02-18 16:41:17', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(66, 1, 1, 'after save tset', 'test', '2011-02-18 16:44:08', '2011-02-18 16:44:08', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(67, 1, 1, 'after save tset', 'test', '2011-02-18 16:47:18', '2011-02-18 16:47:18', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(68, 1, 1, 'after save tset', 'test', '2011-02-18 16:47:53', '2011-02-18 16:47:53', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(69, 1, 1, 'after save tset', 'test', '2011-02-18 16:54:52', '2011-02-18 16:54:52', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(70, 1, 1, 'after save tset', 'test', '2011-02-18 16:55:11', '2011-02-18 16:55:11', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(71, 1, 1, 'after save tset', 'test', '2011-02-18 16:56:02', '2011-02-18 16:56:02', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(72, 1, 1, 'after save tset', 'test', '2011-02-18 16:57:47', '2011-02-18 16:57:47', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(73, 1, 1, 'after save tset', 'test', '2011-02-18 16:58:20', '2011-02-18 16:58:20', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(74, 1, 2, 'qqqqqq', 'qqqqq', '2011-02-18 17:02:41', '2011-02-18 17:02:41', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(75, 1, 1, 'diee abend', 'asdf', '2011-02-22 19:31:42', '2011-02-22 19:31:42', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(76, 3, 4, 'aa', 'bb', '2011-02-25 21:33:26', '2011-02-25 21:33:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(77, 3, 4, 'samstagfrÃ¼h', 'frÃ¼hhh', '2011-02-26 09:38:33', '2011-02-26 09:38:33', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(78, 3, 4, 'samstagfrÃ¼h', 'frÃ¼hhh', '2011-02-26 09:42:42', '2011-02-26 09:42:42', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(79, 3, 4, 'rr', 'rr', '2011-02-26 10:48:54', '2011-02-26 10:48:54', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(80, 3, 4, 'rr', 'rr', '2011-02-26 10:51:59', '2011-02-26 10:51:59', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(81, 3, 4, 'rr', 'rr', '2011-02-26 10:52:13', '2011-02-26 10:52:13', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(82, 3, 4, 'rr', 'rr', '2011-02-26 11:04:23', '2011-02-26 11:04:23', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(83, 3, 4, 'rr', 'rr', '2011-02-26 11:04:34', '2011-02-26 11:04:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(84, 3, 4, 'joggen', 'joggen', '2011-02-26 11:05:00', '2011-02-26 11:05:00', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(85, 3, 4, 'fffffffff', 'ffffffff', '2011-02-26 11:05:32', '2011-02-26 11:05:32', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(86, 3, 4, 'f', 'f', '2011-02-26 11:07:41', '2011-02-26 11:07:41', 1, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `posts_users`
--

DROP TABLE IF EXISTS `posts_users`;
CREATE TABLE `posts_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `posts_users`
--

INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(1, 1, 1, '2011-02-16 19:54:52');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(2, 1, 2, '2011-02-18 13:33:22');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(3, 1, 3, '2011-02-18 13:33:34');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(4, 1, 48, '2011-02-18 16:23:41');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(5, 1, 49, '2011-02-18 16:25:23');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(6, 1, 55, '2011-02-18 16:28:49');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(7, 1, 56, '2011-02-18 16:29:04');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(8, 1, 57, '2011-02-18 16:30:20');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(9, 1, 58, '2011-02-18 16:30:28');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(10, 1, 59, '2011-02-18 16:30:54');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(11, 1, 60, '2011-02-18 16:31:04');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(12, 1, 61, '2011-02-18 16:31:48');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(13, 1, 62, '2011-02-18 16:37:42');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(14, 1, 63, '2011-02-18 16:40:02');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(15, 1, 64, '2011-02-18 16:40:26');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(16, 1, 65, '2011-02-18 16:41:17');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(17, 1, 69, '2011-02-18 16:54:52');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(18, 1, 70, '2011-02-18 16:55:12');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(19, 1, 71, '2011-02-18 16:56:02');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(20, 3, 82, '2011-02-26 11:04:23');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(21, 3, 83, '2011-02-26 11:04:35');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(22, 3, 84, '2011-02-26 11:05:00');
INSERT INTO `posts_users` (`id`, `user_id`, `post_id`, `created`) VALUES(23, 3, 85, '2011-02-26 11:05:32');

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

DROP TABLE IF EXISTS `routes`;
CREATE TABLE `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_id` int(11) NOT NULL,
  `source` varchar(255) NOT NULL,
  `target_controller` varchar(100) NOT NULL,
  `target_action` varchar(100) NOT NULL,
  `target_param` varchar(20) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(1, 0, 'alf', 'users', 'view', '1', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(2, 1, 'alfs paper', 'papers', 'view', '1', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(3, 2, 'second paper', 'papers', 'view', '2', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(4, 0, 'ssecond post', 'posts', 'view', '1', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(5, 0, 'freitaggggggggg_erstessssssssss', 'posts', 'view', '2', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(6, 0, 'freitaggggggggg_zzzzzzzzzzzweitessssssss', 'posts', 'view', '3', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(7, 0, 'after save tset', 'posts', 'view', '48', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(8, 0, 'after save tset', 'posts', 'view', '49', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(9, 0, 'after save tset', 'posts', 'view', '55', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(10, 0, 'after save tset', 'posts', 'view', '56', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(11, 0, 'after save tset', 'posts', 'view', '57', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(12, 0, 'after save tset', 'posts', 'view', '58', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(13, 0, 'after save tset', 'posts', 'view', '59', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(14, 0, 'after save tset', 'posts', 'view', '60', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(15, 0, 'after save tset', 'posts', 'view', '61', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(16, 0, 'after save tset', 'posts', 'view', '62', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(17, 0, 'after save tset', 'posts', 'view', '63', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(18, 0, 'after save tset', 'posts', 'view', '64', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(19, 0, 'after save tset', 'posts', 'view', '65', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(20, 0, 'after save tset', 'posts', 'view', '69', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(21, 0, 'after save tset', 'posts', 'view', '70', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(22, 0, 'after save tset', 'posts', 'view', '71', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(23, 0, 'alf2', 'users', 'view', '2', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(24, 0, 'alf2', 'users', 'view', '3', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(25, 0, 'rr', 'posts', 'view', '82', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(26, 0, 'rr', 'posts', 'view', '83', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(27, 0, 'joggen', 'posts', 'view', '84', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(28, 0, 'fffffffff', 'posts', 'view', '85', 0);

-- --------------------------------------------------------

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
CREATE TABLE `schema_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `schema_migrations`
--

INSERT INTO `schema_migrations` (`id`, `version`, `type`, `created`) VALUES(1, 1, 'migrations', '2011-02-14 22:27:54');
INSERT INTO `schema_migrations` (`id`, `version`, `type`, `created`) VALUES(4, 1, 'app', '2011-02-14 22:39:54');
INSERT INTO `schema_migrations` (`id`, `version`, `type`, `created`) VALUES(5, 4, 'app', '2011-02-14 22:46:34');

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `subscriptions`
--


-- --------------------------------------------------------

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `test` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--


-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
CREATE TABLE `topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `enabled` int(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(1, 'test_topi', 1, '2011-02-15 22:19:57', '2011-02-15 22:19:57', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(2, 'second topoic', 1, '2011-02-16 19:47:16', '2011-02-16 19:47:16', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(3, 'test_topi', 2, '2011-02-24 23:44:52', '2011-02-24 23:44:52', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(4, 'test_topi', 3, '2011-02-24 23:46:52', '2011-02-24 23:46:52', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `firstname` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `group_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(1, 1, 'alf', 'alf', 'alf@alf.de', 'alf', '94afe8c425aec767e47fd14e547fcffb796e66a2', '2011-02-15 22:19:57', '2011-02-15 22:19:57', NULL, 1);
INSERT INTO `users` (`id`, `group_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`) VALUES(3, 1, 'seb', 'alfers', 'alf2@alf2.de', 'alf2', '5072f955ef5abb2c34a88a683fb072ce3862d072', '2011-02-24 23:46:52', '2011-02-24 23:46:52', NULL, 1);
