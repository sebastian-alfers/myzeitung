-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 26. März 2011 um 21:29
-- Server Version: 5.1.44
-- PHP-Version: 5.2.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `myzeitung`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cachekeys`
--

DROP TABLE IF EXISTS `cachekeys`;
CREATE TABLE `cachekeys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL,
  `old_key` varchar(50) NOT NULL,
  `new_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `cachekeys`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cake_sessions`
--

DROP TABLE IF EXISTS `cake_sessions`;
CREATE TABLE `cake_sessions` (
  `id` varchar(255) NOT NULL,
  `data` text,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `cake_sessions`
--

INSERT INTO `cake_sessions` (`id`, `data`, `expires`) VALUES('8ef847c6a1c3f90b4fc78ee01da65599', 'Config|a:3:{s:9:"userAgent";s:32:"502055aebf253fd3349b41c74c2df1de";s:4:"time";i:1301183295;s:7:"timeout";i:10;}Auth|a:1:{s:4:"User";a:13:{s:2:"id";s:1:"6";s:8:"group_id";s:1:"1";s:9:"firstname";s:0:"";s:4:"name";s:0:"";s:5:"email";s:10:"tim@tim.de";s:8:"username";s:3:"tim";s:7:"created";s:19:"2011-03-14 20:48:17";s:8:"modified";s:19:"2011-03-14 20:48:17";s:9:"lastlogin";N;s:7:"enabled";s:1:"1";s:19:"count_posts_reposts";s:2:"50";s:13:"count_reposts";s:2:"24";s:14:"count_comments";s:2:"10";}}', 1301183296);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `paper_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Daten für Tabelle `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(1, 0, 1, 'my super category', '2011-02-15 22:28:13', '2011-02-15 22:28:13');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(2, 0, 1, 'nochne category', '2011-02-15 22:29:19', '2011-02-15 22:29:19');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(3, 0, 0, 'aaaaaaaaaaaaaa', '2011-02-15 22:41:29', '2011-02-15 22:41:29');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(4, 0, 0, 'zzzzzzzzzzzzzz', '2011-02-15 22:41:49', '2011-02-15 22:41:49');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(5, 3, 0, 'sub for zzzzzzzzzzzz', '2011-02-15 23:02:47', '2011-02-15 23:02:47');
INSERT INTO `categories` (`id`, `parent_id`, `paper_id`, `name`, `created`, `modified`) VALUES(6, 1, 0, 'rrrrrrrrrrrrrrrrrr', '2011-02-15 23:04:09', '2011-02-15 23:04:09');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `category_paper_posts`
--

DROP TABLE IF EXISTS `category_paper_posts`;
CREATE TABLE `category_paper_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `paper_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=390 ;

--
-- Daten für Tabelle `category_paper_posts`
--

INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(368, 169, 1, 0, '2011-03-26 11:45:02');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(367, 170, 2, 0, '2011-03-26 11:45:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(366, 170, 1, 0, '2011-03-26 11:45:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(365, 182, 2, 0, '2011-03-26 11:44:59');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(8, 88, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(9, 56, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(364, 182, 1, 0, '2011-03-26 11:44:59');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(363, 165, 2, 0, '2011-03-26 11:44:58');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(362, 165, 1, 0, '2011-03-26 11:44:58');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(361, 183, 2, 0, '2011-03-26 11:44:57');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(14, 1, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(360, 183, 1, 0, '2011-03-26 11:44:57');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(16, 2, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(359, 185, 2, 0, '2011-03-26 11:44:14');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(18, 3, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(358, 187, 2, 0, '2011-03-26 11:44:11');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(20, 20, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(357, 188, 2, 0, '2011-03-26 11:44:07');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(22, 5, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(356, 189, 2, 0, '2011-03-26 11:44:03');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(24, 7, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(355, 190, 2, 0, '2011-03-26 11:43:58');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(26, 8, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(91, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(28, 12, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(117, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(30, 51, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(119, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(32, 71, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(121, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(123, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(125, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(36, 65, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(127, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(129, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(39, 89, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(40, 18, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(131, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(42, 18, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(133, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(44, 18, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(115, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(46, 68, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(113, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(48, 69, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(111, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(50, 75, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(93, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(52, 14, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(95, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(54, 14, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(97, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(56, 13, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(99, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(58, 13, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(101, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(60, 19, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(103, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(62, 19, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(105, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(64, 11, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(107, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(66, 10, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(109, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(68, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(135, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(70, 6, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(137, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(72, 4, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(163, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(74, 4, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(165, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(76, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(167, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(78, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(169, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(80, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(171, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(82, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(173, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(84, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(175, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(86, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(177, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(88, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(179, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(90, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(161, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(92, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(159, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(94, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(157, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(96, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(139, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(98, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(141, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(100, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(143, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(102, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(145, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(104, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(147, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(106, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(149, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(108, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(151, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(110, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(153, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(112, 9, 1, 1, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(155, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(114, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(181, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(116, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(89, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(118, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(5, 86, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(120, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(25, 7, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(122, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(27, 8, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(124, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(29, 12, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(126, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(31, 51, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(128, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(33, 71, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(130, 9, 1, 2, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(34, 79, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(132, 9, 1, 1, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(35, 76, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(134, 9, 1, 2, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(37, 65, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(136, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(38, 77, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(138, 9, 1, 1, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(23, 5, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(140, 9, 1, 1, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(21, 20, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(142, 9, 1, 1, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(19, 3, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(144, 9, 1, 1, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(4, 85, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(146, 9, 1, 1, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(6, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(148, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(7, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(150, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(10, 56, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(152, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(11, 86, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(154, 9, 1, 1, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(12, 85, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(156, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(13, 81, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(158, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(41, 18, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(160, 9, 1, 2, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(43, 18, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(162, 9, 1, 2, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(69, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(164, 9, 1, 2, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(71, 6, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(166, 9, 1, 2, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(73, 4, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(168, 9, 1, 2, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(75, 4, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(170, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(77, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(172, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(79, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(174, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(81, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(176, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(83, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(178, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(85, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(180, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(67, 10, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(182, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(65, 11, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(184, 12, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(63, 19, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(186, 1, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(45, 18, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(188, 1, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(47, 68, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(190, 1, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(49, 69, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(192, 1, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(51, 75, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(194, 1, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(53, 14, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(196, 1, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(55, 14, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(198, 1, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(57, 13, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(200, 1, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(59, 13, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(202, 2, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(61, 19, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(204, 2, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(87, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(206, 2, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(276, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(208, 3, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(289, 129, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(210, 3, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(291, 130, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(212, 4, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(293, 131, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(214, 4, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(295, 132, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(216, 6, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(297, 133, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(218, 6, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(299, 134, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(220, 6, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(301, 135, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(222, 9, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(303, 136, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(224, 11, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(305, 137, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(226, 10, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(288, 113, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(228, 18, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(287, 113, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(230, 18, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(286, 113, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(232, 6, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(277, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(234, 90, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(235, 91, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(236, 92, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(237, 93, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(238, 94, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(239, 95, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(240, 96, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(241, 97, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(242, 98, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(243, 99, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(244, 100, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(245, 101, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(246, 102, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(247, 103, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(248, 104, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(249, 105, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(250, 106, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(251, 107, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(252, 108, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(253, 109, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(254, 87, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(278, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(279, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(280, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(281, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(282, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(283, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(284, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(285, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(307, 138, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(309, 139, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(335, 152, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(337, 153, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(339, 154, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(341, 155, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(343, 156, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(345, 157, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(347, 158, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(349, 159, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(351, 160, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(333, 151, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(331, 150, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(329, 149, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(311, 140, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(313, 141, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(315, 142, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(317, 143, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(319, 144, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(321, 145, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(323, 146, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(325, 147, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(327, 148, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(275, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(183, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(209, 3, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(211, 3, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(290, 129, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(213, 4, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(292, 130, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(215, 4, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(294, 131, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(217, 6, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(296, 132, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(219, 6, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(298, 133, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(221, 6, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(300, 134, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(223, 9, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(302, 135, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(225, 11, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(304, 136, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(185, 12, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(306, 137, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(227, 10, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(308, 138, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(229, 18, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(310, 139, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(265, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(312, 140, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(266, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(314, 141, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(267, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(316, 142, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(268, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(318, 143, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(269, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(320, 144, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(270, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(322, 145, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(271, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(324, 146, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(272, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(326, 147, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(273, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(328, 148, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(264, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(330, 149, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(263, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(332, 150, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(262, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(334, 151, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(231, 18, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(336, 152, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(233, 6, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(338, 153, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(255, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(340, 154, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(256, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(342, 155, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(257, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(344, 156, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(258, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(346, 157, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(259, 110, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(348, 158, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(260, 111, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(350, 159, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(261, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(352, 160, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(274, 87, 2, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(354, 161, 1, 0, '0000-00-00 00:00:00');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(369, 169, 2, 0, '2011-03-26 11:45:02');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(370, 168, 1, 0, '2011-03-26 11:45:03');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(371, 168, 2, 0, '2011-03-26 11:45:03');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(372, 163, 1, 0, '2011-03-26 11:45:09');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(373, 163, 2, 0, '2011-03-26 11:45:09');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(374, 164, 1, 0, '2011-03-26 11:45:11');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(375, 164, 2, 0, '2011-03-26 11:45:11');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(376, 166, 1, 0, '2011-03-26 11:45:13');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(377, 166, 2, 0, '2011-03-26 11:45:13');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(378, 167, 1, 0, '2011-03-26 11:45:15');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(379, 167, 2, 0, '2011-03-26 11:45:15');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(380, 183, 2, 0, '2011-03-26 11:45:32');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(381, 165, 2, 0, '2011-03-26 11:45:33');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(382, 182, 2, 0, '2011-03-26 11:45:35');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(383, 170, 2, 0, '2011-03-26 11:45:36');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(384, 169, 2, 0, '2011-03-26 11:45:37');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(385, 168, 2, 0, '2011-03-26 11:45:40');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(386, 167, 2, 0, '2011-03-26 11:45:42');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(387, 163, 2, 0, '2011-03-26 11:45:43');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(388, 164, 2, 0, '2011-03-26 11:45:44');
INSERT INTO `category_paper_posts` (`id`, `post_id`, `paper_id`, `category_id`, `created`) VALUES(389, 166, 2, 0, '2011-03-26 11:45:46');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `text` text NOT NULL,
  `created` datetime NOT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=98 ;

--
-- Daten für Tabelle `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(44, 4, 87, NULL, 'hans', '2011-03-06 19:01:20', 31, 32);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(43, 4, 87, NULL, 'new comment', '2011-03-06 19:00:29', 27, 30);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(42, 4, 87, NULL, 'jo', '2011-03-06 18:50:33', 25, 26);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(41, 4, 87, NULL, 'jo', '2011-03-06 18:50:30', 23, 24);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(40, 4, 87, NULL, 'jo', '2011-03-06 18:50:26', 21, 22);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(39, 4, 87, NULL, 'jo', '2011-03-06 18:50:02', 19, 20);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(38, 4, 87, NULL, 'jo', '2011-03-06 18:49:16', 17, 18);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(37, 4, 87, NULL, 'jo', '2011-03-06 18:48:57', 15, 16);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(36, 4, 87, NULL, 'bla', '2011-03-06 18:48:46', 13, 14);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(35, 4, 87, NULL, 'bla', '2011-03-06 18:48:42', 11, 12);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(34, 4, 87, NULL, 'bla', '2011-03-06 18:48:33', 9, 10);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(33, 4, 87, NULL, 'bla', '2011-03-06 18:48:00', 7, 8);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(32, 4, 87, NULL, 'bla', '2011-03-06 18:47:41', 5, 6);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(31, 4, 87, 30, 'bla\r\n', '2011-03-06 18:22:57', 2, 3);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(30, 4, 87, NULL, 'bla', '2011-03-06 17:20:57', 1, 4);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(45, 4, 87, NULL, 'bla', '2011-03-06 19:01:37', 33, 34);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(46, 4, 87, NULL, 'hans', '2011-03-06 19:03:38', 35, 36);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(47, 4, 87, NULL, 'hans', '2011-03-06 19:06:56', 37, 38);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(48, 4, 87, NULL, 'hans', '2011-03-06 19:07:39', 39, 40);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(49, 4, 87, NULL, 'hans', '2011-03-06 19:13:12', 41, 42);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(50, 4, 87, NULL, 'karl', '2011-03-06 19:16:00', 43, 44);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(51, 4, 87, NULL, 'karl', '2011-03-06 19:16:39', 45, 46);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(52, 4, 87, NULL, 'copy', '2011-03-06 19:18:21', 47, 48);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(53, 4, 87, NULL, 'bla', '2011-03-06 19:27:11', 49, 50);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(54, 4, 87, NULL, 'bla', '2011-03-06 19:29:58', 51, 52);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(55, 4, 3, NULL, 'test', '2011-03-07 11:12:52', 53, 54);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(56, 4, 87, NULL, 'bla', '2011-03-07 11:22:47', 55, 56);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(57, 4, 87, NULL, 'bla', '2011-03-07 11:24:06', 57, 58);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(58, 4, 87, NULL, 'bla', '2011-03-07 11:24:29', 59, 60);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(59, 4, 87, NULL, 'blup', '2011-03-07 11:47:21', 61, 62);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(60, 4, 87, NULL, 'neuester\r\n', '2011-03-07 11:47:41', 63, 84);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(61, 4, 87, 60, 'bla', '2011-03-07 12:40:36', 64, 65);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(62, 4, 87, 60, 'reply', '2011-03-07 13:21:51', 66, 73);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(63, 4, 87, 62, 'test', '2011-03-07 14:43:50', 67, 68);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(64, 4, 87, 62, 'bla', '2011-03-07 14:44:19', 69, 70);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(65, 4, 87, 60, 'bla\r\n', '2011-03-07 14:44:33', 74, 75);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(66, 4, 87, 60, 'bla', '2011-03-07 14:44:41', 76, 83);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(67, 4, 87, 62, 'rep rep', '2011-03-07 14:46:04', 71, 72);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(68, 4, 87, NULL, 'jo', '2011-03-07 14:47:49', 85, 86);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(69, 4, 87, 66, 'bla', '2011-03-07 15:06:29', 77, 78);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(70, 4, 87, NULL, 'geiler aftersave geht nicht oder?', '2011-03-07 15:26:25', 87, 88);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(71, 4, 87, NULL, 'geiler aftersave geht nicht oder?', '2011-03-07 15:27:00', 89, 90);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(72, 4, 87, NULL, 'bla', '2011-03-07 20:32:44', 91, 92);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(73, 4, 87, NULL, 'bla', '2011-03-07 20:33:42', 93, 94);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(74, 4, 87, NULL, 'bla', '2011-03-07 20:34:59', 95, 96);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(75, 4, 87, NULL, 'bla', '2011-03-07 20:35:20', 97, 98);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(76, 4, 119, NULL, 'test', '2011-03-13 11:31:59', 99, 100);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(77, 4, 119, NULL, 'find ich auch', '2011-03-13 11:34:02', 101, 108);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(78, 4, 119, 77, 'was findest du auch', '2011-03-13 11:34:08', 102, 107);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(79, 4, 119, 78, 'meinen pipi-mann', '2011-03-13 11:34:16', 103, 104);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(80, 4, 119, 78, 'sch?É¬?n f?É¬ºr dich\r\n', '2011-03-13 11:34:22', 105, 106);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(81, 4, 87, 66, 'blup', '2011-03-13 12:11:26', 79, 80);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(82, 4, 87, 66, 'blap', '2011-03-13 12:11:34', 81, 82);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(83, 4, 87, NULL, 'jetzt', '2011-03-13 15:23:45', 109, 116);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(84, 4, 87, 83, 'antwort', '2011-03-13 15:23:51', 110, 115);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(85, 4, 87, 84, 'antant\r\n', '2011-03-13 15:23:57', 111, 112);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(86, 4, 87, 84, 'antantant', '2011-03-13 15:24:05', 113, 114);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(87, 4, 87, 43, 'ant', '2011-03-13 15:24:42', 28, 29);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(88, 6, 166, NULL, 'bla', '2011-03-16 11:18:04', 117, 118);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(89, 6, 185, NULL, 'blup ', '2011-03-20 23:23:22', 119, 126);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(90, 6, 185, NULL, 'blap\r\n', '2011-03-20 23:23:31', 127, 128);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(91, 6, 185, 89, 'du blupst ja nicht sauber', '2011-03-20 23:23:40', 120, 125);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(92, 6, 185, 91, 'ich bin blubber nicht blogger', '2011-03-20 23:23:51', 121, 122);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(93, 6, 185, 91, 'geeeil', '2011-03-20 23:23:58', 123, 124);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(94, 6, 9, NULL, 'bla', '2011-03-25 23:23:54', 129, 130);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(95, 6, 4, NULL, 'geilo', '2011-03-26 13:39:24', 131, 136);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(96, 6, 4, 95, 'jau', '2011-03-26 13:39:31', 132, 135);
INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `text`, `created`, `lft`, `rght`) VALUES(97, 6, 4, 96, 'jau', '2011-03-26 13:39:36', 133, 134);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `content_papers`
--

DROP TABLE IF EXISTS `content_papers`;
CREATE TABLE `content_papers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `topic_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Daten für Tabelle `content_papers`
--

INSERT INTO `content_papers` (`id`, `paper_id`, `category_id`, `user_id`, `topic_id`) VALUES(4, 1, NULL, NULL, 4);
INSERT INTO `content_papers` (`id`, `paper_id`, `category_id`, `user_id`, `topic_id`) VALUES(10, 1, NULL, 1, NULL);
INSERT INTO `content_papers` (`id`, `paper_id`, `category_id`, `user_id`, `topic_id`) VALUES(11, 2, NULL, 1, NULL);
INSERT INTO `content_papers` (`id`, `paper_id`, `category_id`, `user_id`, `topic_id`) VALUES(12, 2, NULL, 3, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `groups`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `i18n`
--

DROP TABLE IF EXISTS `i18n`;
CREATE TABLE `i18n` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `locale` varchar(6) NOT NULL,
  `model` varchar(255) NOT NULL,
  `foreign_key` int(10) NOT NULL,
  `field` varchar(255) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `locale` (`locale`),
  KEY `model` (`model`),
  KEY `row_id` (`foreign_key`),
  KEY `field` (`field`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `i18n`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `installs`
--

DROP TABLE IF EXISTS `installs`;
CREATE TABLE `installs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `namespace` varchar(100) NOT NULL,
  `version` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `installs`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `papers`
--

DROP TABLE IF EXISTS `papers`;
CREATE TABLE `papers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `count_subscriptions` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Daten für Tabelle `papers`
--

INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`, `count_subscriptions`) VALUES(1, 1, 'alfs paper', 'my paper', '', '2011-02-15 22:20:44', '2011-02-15 22:20:44', -3);
INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`, `count_subscriptions`) VALUES(2, 1, 'second paper', 'aaaaaaaaaaaaaaaaaaaaa', '', '2011-02-15 22:41:09', '2011-02-15 22:41:09', -2);
INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`, `count_subscriptions`) VALUES(9, 6, 'pansen', 'jo', '', '2011-03-24 17:04:04', '2011-03-24 17:04:04', 0);
INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`, `count_subscriptions`) VALUES(10, 6, 'test', 'test', 'jo', '2011-03-24 17:14:46', '2011-03-24 17:14:46', 0);
INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`, `count_subscriptions`) VALUES(11, 6, 'test2', 'test2', '', '2011-03-24 17:16:20', '2011-03-24 17:16:20', 0);
INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`, `count_subscriptions`) VALUES(12, 6, 'test2', 'test2', '', '2011-03-24 17:17:47', '2011-03-24 17:17:47', 0);
INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`, `count_subscriptions`) VALUES(13, 6, 'test2', 'test2', '', '2011-03-24 17:18:07', '2011-03-24 17:18:07', 0);
INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`, `count_subscriptions`) VALUES(14, 6, 'test', 'jo', '', '2011-03-24 17:18:46', '2011-03-24 17:18:46', 0);
INSERT INTO `papers` (`id`, `owner_id`, `title`, `description`, `url`, `created`, `modified`, `count_subscriptions`) VALUES(15, 1, 'donnerstag', 'donnerstag', '', '2011-03-24 21:13:04', '2011-03-24 21:13:04', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(300) DEFAULT NULL,
  `modified` datetime NOT NULL,
  `created` datetime NOT NULL,
  `enabled` int(3) NOT NULL DEFAULT '1',
  `count_views` int(11) NOT NULL DEFAULT '0',
  `count_reposts` int(11) NOT NULL DEFAULT '0',
  `count_comments` int(11) NOT NULL DEFAULT '0',
  `reposters` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=191 ;

--
-- Daten für Tabelle `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(3, 1, 2, 'freitaggggggggg_zzzzzzzzzzzweitessssssss', 'freitaggggggggg_zzzzzzzzzzzweitessssssss', NULL, '2011-02-18 13:33:34', '2011-02-18 13:33:34', 1, 17, 1, 0, 'a:1:{i:1;s:1:"4";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(4, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 14:58:25', '2011-02-18 14:58:25', 1, 2, 0, 3, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(5, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:06:26', '2011-02-18 15:06:26', 1, 1, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(6, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:06:42', '2011-02-18 15:06:42', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(7, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:06:50', '2011-02-18 15:06:50', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(8, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:07:00', '2011-02-18 15:07:00', 1, 0, 1, 0, 'a:1:{i:0;s:1:"4";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(9, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:07:55', '2011-02-18 15:07:55', 1, 1, 1, 1, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(10, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:09:42', '2011-02-18 15:09:42', 1, 1, 2, 0, 'a:2:{i:0;s:1:"3";i:1;s:1:"4";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(11, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:09:55', '2011-02-18 15:09:55', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(12, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:10:03', '2011-02-18 15:10:03', 1, 0, 1, 0, 'a:1:{i:0;s:1:"4";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(13, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:11:04', '2011-02-18 15:11:04', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(14, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:11:11', '2011-02-18 15:11:11', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(15, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:11:24', '2011-02-18 15:11:24', 1, 1, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(16, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:15:55', '2011-02-18 15:15:55', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(17, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:16:22', '2011-02-18 15:16:22', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(18, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:19:13', '2011-02-18 15:19:13', 1, 1, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(19, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:20:11', '2011-02-18 15:20:11', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(20, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:20:21', '2011-02-18 15:20:21', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(21, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:21:49', '2011-02-18 15:21:49', 1, 4, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(22, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:21:56', '2011-02-18 15:21:56', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(23, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:22:44', '2011-02-18 15:22:44', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(24, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:22:52', '2011-02-18 15:22:52', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(25, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:24:30', '2011-02-18 15:24:30', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(26, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:24:34', '2011-02-18 15:24:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(27, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:24:39', '2011-02-18 15:24:39', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(28, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:26:26', '2011-02-18 15:26:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(29, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:26:52', '2011-02-18 15:26:52', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(30, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:27:04', '2011-02-18 15:27:04', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(31, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:27:56', '2011-02-18 15:27:56', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(32, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:33:10', '2011-02-18 15:33:10', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(33, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:35:01', '2011-02-18 15:35:01', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(34, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:35:50', '2011-02-18 15:35:50', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(35, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:36:13', '2011-02-18 15:36:13', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(36, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:38:07', '2011-02-18 15:38:07', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(37, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:39:37', '2011-02-18 15:39:37', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(38, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:39:46', '2011-02-18 15:39:46', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(39, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:39:57', '2011-02-18 15:39:57', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(40, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:41:10', '2011-02-18 15:41:10', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(41, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:41:29', '2011-02-18 15:41:29', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(42, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 15:47:29', '2011-02-18 15:47:29', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(43, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:00:06', '2011-02-18 16:00:06', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(44, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:07:03', '2011-02-18 16:07:03', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(45, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:07:05', '2011-02-18 16:07:05', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(46, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:08:26', '2011-02-18 16:08:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(47, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:08:32', '2011-02-18 16:08:32', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(48, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:23:41', '2011-02-18 16:23:41', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(49, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:25:23', '2011-02-18 16:25:23', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(50, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:26:19', '2011-02-18 16:26:19', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(51, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:27:30', '2011-02-18 16:27:30', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(52, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:27:41', '2011-02-18 16:27:41', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(53, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:28:05', '2011-02-18 16:28:05', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(54, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:28:15', '2011-02-18 16:28:15', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(55, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:28:49', '2011-02-18 16:28:49', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(56, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:29:04', '2011-02-18 16:29:04', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(57, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:30:20', '2011-02-18 16:30:20', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(58, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:30:28', '2011-02-18 16:30:28', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(59, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:30:54', '2011-02-18 16:30:54', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(60, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:31:04', '2011-02-18 16:31:04', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(61, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:31:48', '2011-02-18 16:31:48', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(62, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:37:42', '2011-02-18 16:37:42', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(63, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:40:02', '2011-02-18 16:40:02', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(64, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:40:26', '2011-02-18 16:40:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(65, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:41:17', '2011-02-18 16:41:17', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(66, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:44:08', '2011-02-18 16:44:08', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(67, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:47:18', '2011-02-18 16:47:18', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(68, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:47:53', '2011-02-18 16:47:53', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(69, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:54:52', '2011-02-18 16:54:52', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(70, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:55:11', '2011-02-18 16:55:11', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(71, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:56:02', '2011-02-18 16:56:02', 1, 0, 2, 0, 'a:2:{i:0;s:1:"3";i:1;s:1:"4";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(72, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:57:47', '2011-02-18 16:57:47', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(73, 1, 1, 'after save tset', 'test', NULL, '2011-02-18 16:58:20', '2011-02-18 16:58:20', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(74, 1, 2, 'qqqqqq', 'qqqqq', NULL, '2011-02-18 17:02:41', '2011-02-18 17:02:41', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(75, 1, 1, 'diee abend', 'asdf', NULL, '2011-02-22 19:31:42', '2011-02-22 19:31:42', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(76, 3, 4, 'aa', 'bb', NULL, '2011-02-25 21:33:26', '2011-02-25 21:33:26', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(77, 3, 4, 'samstagfr??â¬¨¬?h', 'fr??â¬¨¬?hhh', NULL, '2011-02-26 09:38:33', '2011-02-26 09:38:33', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(78, 3, 4, 'samstagfr??â¬¨¬?h', 'fr??â¬¨¬?hhh', NULL, '2011-02-26 09:42:42', '2011-02-26 09:42:42', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(79, 3, 4, 'rr', 'rr', NULL, '2011-02-26 10:48:54', '2011-02-26 10:48:54', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(80, 3, 4, 'rr', 'rr', NULL, '2011-02-26 10:51:59', '2011-02-26 10:51:59', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(81, 3, 4, 'rr', 'rr', NULL, '2011-02-26 10:52:13', '2011-02-26 10:52:13', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(82, 3, 4, 'rr', 'rr', NULL, '2011-02-26 11:04:23', '2011-02-26 11:04:23', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(83, 3, 4, 'rr', 'rr', NULL, '2011-02-26 11:04:34', '2011-02-26 11:04:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(84, 3, 4, 'joggen', 'joggen', NULL, '2011-02-26 11:05:00', '2011-02-26 11:05:00', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(85, 3, 4, 'fffffffff', 'ffffffff', NULL, '2011-02-26 11:05:32', '2011-02-26 11:05:32', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(86, 3, 4, 'f', 'f', NULL, '2011-02-26 11:07:41', '2011-02-26 11:07:41', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(87, 3, 2, 'timtestbkj', 'timtest', NULL, '2011-03-07 20:36:40', '2011-03-02 11:24:28', 1, 0, 2, 26, 'a:2:{i:0;s:1:"3";i:2;s:1:"4";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(88, 0, 0, '', '', NULL, '2011-03-02 11:52:09', '2011-03-02 11:52:09', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(89, 0, 0, '', '', NULL, '2011-03-02 15:11:57', '2011-03-02 15:11:57', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(90, 0, 0, '', '', NULL, '2011-03-05 12:21:15', '2011-03-05 12:21:15', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(91, 0, 0, '', '', NULL, '2011-03-05 12:22:13', '2011-03-05 12:22:13', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(92, 0, 0, '', '', NULL, '2011-03-05 12:23:14', '2011-03-05 12:23:14', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(93, 0, 0, '', '', NULL, '2011-03-05 12:23:50', '2011-03-05 12:23:50', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(94, 0, 0, '', '', NULL, '2011-03-05 12:24:36', '2011-03-05 12:24:36', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(95, 0, 0, '', '', NULL, '2011-03-05 12:27:51', '2011-03-05 12:27:51', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(96, 0, 0, '', '', NULL, '2011-03-05 12:28:53', '2011-03-05 12:28:53', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(97, 0, 0, '', '', NULL, '2011-03-05 12:35:38', '2011-03-05 12:35:38', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(98, 0, 0, '', '', NULL, '2011-03-05 12:41:11', '2011-03-05 12:41:11', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(99, 0, 0, '', '', NULL, '2011-03-05 12:41:58', '2011-03-05 12:41:58', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(100, 0, 0, '', '', NULL, '2011-03-05 12:43:25', '2011-03-05 12:43:25', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(101, 0, 0, '', '', NULL, '2011-03-05 12:49:22', '2011-03-05 12:49:22', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(102, 0, 0, '', '', NULL, '2011-03-05 13:01:26', '2011-03-05 13:01:26', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(103, 0, 0, '', '', NULL, '2011-03-05 13:03:11', '2011-03-05 13:03:11', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(104, 0, 0, '', '', NULL, '2011-03-05 13:06:39', '2011-03-05 13:06:39', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(105, 0, 0, '', '', NULL, '2011-03-05 14:05:01', '2011-03-05 14:05:01', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(106, 0, 0, '', '', NULL, '2011-03-05 14:05:25', '2011-03-05 14:05:25', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(107, 0, 0, '', '', NULL, '2011-03-05 14:05:45', '2011-03-05 14:05:45', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(108, 0, 0, '', '', NULL, '2011-03-05 14:06:06', '2011-03-05 14:06:06', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(109, 0, 0, '', '', NULL, '2011-03-05 14:11:44', '2011-03-05 14:11:44', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(110, 3, 4, 'test', 'test neu', NULL, '2011-03-05 20:01:49', '2011-03-05 20:01:49', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(111, 3, 4, 'test', 'test neu', NULL, '2011-03-05 20:02:28', '2011-03-05 20:02:28', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(112, 0, 0, '', '', NULL, '2011-03-06 18:47:41', '2011-03-06 18:47:41', 1, 0, 0, 1, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(113, 3, 4, 'pansen', 'pansen', NULL, '2011-03-09 14:51:24', '2011-03-09 14:51:24', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(114, 3, 4, 'bla', 'bla', NULL, '2011-03-09 15:10:57', '2011-03-09 15:10:57', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(115, 4, 5, 'kein repost hier -echter post', 'jo', NULL, '2011-03-13 10:50:14', '2011-03-13 10:50:14', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(116, 4, 5, 'kein repost echter post', 'geil', NULL, '2011-03-13 10:55:30', '2011-03-13 10:55:30', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(117, 4, 5, 'bla', 'bla', NULL, '2011-03-13 11:07:46', '2011-03-13 11:07:46', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(118, 4, 5, 'test ', 'testhjolalala', NULL, '2011-03-13 14:01:21', '2011-03-13 11:08:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(119, 4, 5, 'geilo', 'geillooohoooo', NULL, '2011-03-13 13:51:06', '2011-03-13 11:28:00', 1, 0, 0, 5, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(120, 3, 4, 'asdf', 'asdf', NULL, '2011-03-13 20:37:18', '2011-03-13 20:37:18', 1, 1, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(121, 3, 4, 'asdf', 'asdf', NULL, '2011-03-13 20:37:46', '2011-03-13 20:37:46', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(122, 3, 4, 'asdf', 'asdf', NULL, '2011-03-13 20:38:27', '2011-03-13 20:38:27', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(123, 3, 4, 'asdf', 'asdf', NULL, '2011-03-13 20:39:30', '2011-03-13 20:39:30', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(124, 3, 4, 'asdf', 'asdf\r\n', NULL, '2011-03-13 20:40:18', '2011-03-13 20:40:18', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(125, 3, 4, 'asdf', 'asdf\r\n', NULL, '2011-03-13 20:41:09', '2011-03-13 20:41:09', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(126, 3, 4, 'asdf', 'asdf\r\n', NULL, '2011-03-13 20:41:27', '2011-03-13 20:41:27', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(127, 3, 4, 'dff img', 'asdf', NULL, '2011-03-13 22:14:05', '2011-03-13 22:14:05', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(128, 3, 4, 'adsf', 'asdf', NULL, '2011-03-13 22:14:49', '2011-03-13 22:14:49', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(129, 3, 4, 'asdf', 'fdsa', NULL, '2011-03-13 22:17:28', '2011-03-13 22:17:28', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(130, 3, 4, 'asdf', 'fdsa', NULL, '2011-03-13 22:18:15', '2011-03-13 22:18:15', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(131, 3, 4, 'asdf', 'fdsa', NULL, '2011-03-13 22:19:06', '2011-03-13 22:19:06', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(132, 3, 4, 'asdf', 'fdsa', NULL, '2011-03-13 22:19:17', '2011-03-13 22:19:17', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(133, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:39:17', '2011-03-13 22:39:17', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(134, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:39:45', '2011-03-13 22:39:45', 1, 0, 1, 0, 'a:1:{i:0;s:1:"6";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(135, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:40:10', '2011-03-13 22:40:10', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(136, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:40:44', '2011-03-13 22:40:44', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(137, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:41:18', '2011-03-13 22:41:18', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(138, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:43:03', '2011-03-13 22:43:03', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(139, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:43:26', '2011-03-13 22:43:26', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(140, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:43:36', '2011-03-13 22:43:36', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(141, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:43:57', '2011-03-13 22:43:57', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(142, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:44:13', '2011-03-13 22:44:13', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(143, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:44:21', '2011-03-13 22:44:21', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(144, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:44:41', '2011-03-13 22:44:41', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(145, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:44:52', '2011-03-13 22:44:52', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(146, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:53:38', '2011-03-13 22:53:38', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(147, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:54:19', '2011-03-13 22:54:19', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(148, 3, 4, 'asdf', 'sdf', NULL, '2011-03-13 22:54:56', '2011-03-13 22:54:56', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(149, 3, 4, 'asdf', 'sdf', 'Bildschirmfoto 2011-02-25 um 13.41.21.png', '2011-03-13 22:58:47', '2011-03-13 22:58:47', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(150, 3, 4, 'asdf', 'sdf', 'Bildschirmfoto 2011-02-25 um 13.41.21.png', '2011-03-13 22:59:14', '2011-03-13 22:59:14', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(151, 3, 4, 'asdf', 'sdf', 'Bildschirmfoto 2011-02-25 um 13.41.21.png', '2011-03-13 22:59:46', '2011-03-13 22:59:46', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(152, 3, 4, 'asdf', 'sdf', 'Bildschirmfoto 2011-02-25 um 13.41.21.png', '2011-03-13 23:00:15', '2011-03-13 23:00:15', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(153, 6, NULL, 'test', 'test', NULL, '2011-03-14 20:45:36', '2011-03-14 20:45:36', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(154, 6, NULL, 'test', 'test', NULL, '2011-03-14 20:47:09', '2011-03-14 20:47:09', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(155, 6, NULL, 'bla', 'bla', '', '2011-03-14 20:49:30', '2011-03-14 20:49:30', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(156, 6, NULL, 'bla', 'bla', 'mckinsey_tune_2011.gif', '2011-03-14 20:50:23', '2011-03-14 20:50:23', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(157, 6, NULL, 'bla', 'bla', 'mckinsey_tune_2011.gif', '2011-03-14 21:03:39', '2011-03-14 21:03:39', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(158, 6, NULL, 'bla', 'bla', 'mckinsey_tune_2011.gif', '2011-03-14 21:05:40', '2011-03-14 21:05:40', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(159, 6, NULL, 'bla', 'bla', 'mckinsey_tune_2011.gif', '2011-03-14 21:07:26', '2011-03-14 21:07:26', 1, 1, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(160, 6, 7, 'bla', 'bla', 'mckinsey_tune_2011.gif', '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(163, 6, 7, 'title ', 'content', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 2, 0, 'a:2:{i:0;s:1:"1";i:1;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(164, 6, 7, 'bla', 'bla', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 2, 0, 'a:2:{i:0;s:1:"1";i:1;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(165, 6, 8, 'jou', 'jou', '', '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 2, 0, 'a:2:{i:0;s:1:"1";i:1;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(170, 6, 9, 'asdsgag', 'ahha', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 2, 0, 'a:2:{i:0;s:1:"1";i:1;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(171, 6, 9, 'gafnjadn', 'ksjgksdjgka', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(172, 6, 10, 'gdfkgos', 'älpü', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(173, 6, 10, '65986', 'i34', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(174, 6, 10, 'k098', 'lk69', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(175, 6, 10, 'sß4', '324235', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(176, 6, 10, '59429582', '349', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(177, 6, 11, 'zuuiop', 'popop', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(178, 6, 11, '123456', '54395', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(179, 6, 12, 'maybe', 'maybe', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(180, 6, 12, 'ja', 'ja', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 1, 0, 'a:1:{i:0;s:1:"4";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(181, 6, 12, 'haha', 'blabla', NULL, '2011-03-14 21:12:34', '2011-03-14 21:12:34', 1, 0, 1, 0, 'a:1:{i:0;s:1:"4";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(185, 6, 7, 'bla', 'bla', '', '2011-03-16 12:56:13', '2011-03-16 12:56:13', 1, 1, 1, 5, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(186, 6, 7, 'bla', 'bla', 'IMG_3032.JPG', '2011-03-16 12:56:28', '2011-03-16 12:56:28', 1, 0, 0, 0, NULL);
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(187, 6, 9, 'bla', 'bla', 'Bildschirmfoto 2011-03-16 um 12.57.09.png', '2011-03-16 12:57:21', '2011-03-16 12:57:21', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(188, 6, 7, 'bla', '<p>\r\n	&lt;blockquote&gt; &lt;h1&gt; &lt;strong&gt;&lt;u&gt;dasdsad&lt;em&gt;fdaffdf&lt;/em&gt;&lt;/u&gt;&lt;/strong&gt;&lt;/h1&gt; &lt;/blockquote&gt;</p>\r\n', '', '2011-03-16 16:59:26', '2011-03-16 16:59:26', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(189, 6, 7, 'jo', '<blockquote>\r\n	<p>\r\n		blabla</p>\r\n</blockquote>\r\n', '', '2011-03-16 17:00:14', '2011-03-16 17:00:14', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');
INSERT INTO `posts` (`id`, `user_id`, `topic_id`, `title`, `content`, `image`, `modified`, `created`, `enabled`, `count_views`, `count_reposts`, `count_comments`, `reposters`) VALUES(190, 6, 7, 'bal', '<p>\r\n	bla</p>\r\n', '', '2011-03-18 10:15:33', '2011-03-18 10:15:33', 1, 0, 1, 0, 'a:1:{i:0;s:1:"3";}');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `posts_users`
--

DROP TABLE IF EXISTS `posts_users`;
CREATE TABLE `posts_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `repost` tinyint(4) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) DEFAULT NULL,
  `post_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=266 ;

--
-- Daten für Tabelle `posts_users`
--

INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(1, 0, 1, 0, 1, '2011-02-16 19:54:52');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(2, 0, 1, 0, 2, '2011-02-18 13:33:22');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(3, 0, 1, 0, 3, '2011-02-18 13:33:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(4, 0, 1, 0, 48, '2011-02-18 16:23:41');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(5, 0, 1, 0, 49, '2011-02-18 16:25:23');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(6, 0, 1, 0, 55, '2011-02-18 16:28:49');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(7, 0, 1, 0, 56, '2011-02-18 16:29:04');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(8, 0, 1, 0, 57, '2011-02-18 16:30:20');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(9, 0, 1, 0, 58, '2011-02-18 16:30:28');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(10, 0, 1, 0, 59, '2011-02-18 16:30:54');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(11, 0, 1, 0, 60, '2011-02-18 16:31:04');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(12, 0, 1, 0, 61, '2011-02-18 16:31:48');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(13, 0, 1, 0, 62, '2011-02-18 16:37:42');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(14, 0, 1, 0, 63, '2011-02-18 16:40:02');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(15, 0, 1, 0, 64, '2011-02-18 16:40:26');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(16, 0, 1, 0, 65, '2011-02-18 16:41:17');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(17, 0, 1, 0, 69, '2011-02-18 16:54:52');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(18, 0, 1, 0, 70, '2011-02-18 16:55:12');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(19, 0, 1, 0, 71, '2011-02-18 16:56:02');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(20, 0, 3, 0, 82, '2011-02-26 11:04:23');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(21, 0, 3, 0, 83, '2011-02-26 11:04:35');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(22, 0, 3, 0, 84, '2011-02-26 11:05:00');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(23, 0, 3, 0, 85, '2011-02-26 11:05:32');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(108, 1, 3, 1, 87, '2011-03-06 17:07:14');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(25, 1, 3, 1, 99, '2011-03-02 11:52:09');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(26, 1, 3, 1, 56, '2011-03-02 11:58:28');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(27, 1, 3, 1, 88, '2011-03-02 12:26:43');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(28, 1, 3, 1, 86, '2011-03-02 12:28:09');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(29, 1, 3, 1, 85, '2011-03-02 12:32:08');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(30, 1, 3, 1, 81, '2011-03-02 12:33:13');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(31, 1, 3, 1, 1, '2011-03-02 12:51:22');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(32, 1, 3, 1, 2, '2011-03-02 12:54:09');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(33, 1, 3, 1, 3, '2011-03-02 12:57:40');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(34, 1, 3, 1, 20, '2011-03-02 14:29:52');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(35, 1, 3, 1, 5, '2011-03-02 14:32:11');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(36, 1, 3, 1, 7, '2011-03-02 14:37:18');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(37, 1, 3, 1, 8, '2011-03-02 14:41:41');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(38, 1, 3, 1, 12, '2011-03-02 14:41:53');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(39, 1, 3, 1, 51, '2011-03-02 14:47:52');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(40, 1, 3, 1, 52, '2011-03-02 14:52:01');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(41, 1, 3, 1, 61, '2011-03-02 14:57:02');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(42, 1, 3, 1, 62, '2011-03-02 14:57:20');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(43, 1, 3, 1, 63, '2011-03-02 14:59:43');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(44, 1, 3, 1, 64, '2011-03-02 15:00:16');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(45, 1, 3, 1, 67, '2011-03-02 15:01:56');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(46, 1, 3, 1, 73, '2011-03-02 15:02:55');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(47, 1, 3, 1, 80, '2011-03-02 15:03:43');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(48, 1, 3, 1, 71, '2011-03-02 15:04:27');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(49, 1, 3, 1, 79, '2011-03-02 15:08:42');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(50, 1, 3, 1, 76, '2011-03-02 15:09:36');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(61, 1, 3, 1, 11, '2011-03-02 16:44:59');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(52, 1, 3, 1, 77, '2011-03-02 15:10:55');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(62, 1, 3, 1, 10, '2011-03-02 16:45:02');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(92, 1, 3, 1, 9, '2011-03-02 16:56:13');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(64, 1, 3, 1, 6, '2011-03-02 16:45:11');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(93, 1, 4, 1, 12, '2011-03-02 16:56:55');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(99, 1, 4, 1, 2, '2011-03-03 09:45:29');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(128, 1, 4, 1, 71, '2011-03-13 19:31:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(106, 1, 4, 1, 10, '2011-03-03 09:45:58');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(110, 0, 3, 0, 113, '2011-03-09 14:51:24');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(111, 0, 4, 5, 118, '2011-03-13 11:08:27');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(112, 0, 4, 5, 119, '2011-03-13 11:28:00');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(127, 1, 4, 1, 8, '2011-03-13 15:29:44');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(129, 0, 3, 4, 120, '2011-03-13 20:37:19');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(130, 0, 3, 4, 121, '2011-03-13 20:38:11');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(131, 0, 3, 4, 122, '2011-03-13 20:38:27');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(132, 0, 3, 4, 123, '2011-03-13 20:39:30');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(133, 0, 3, 4, 124, '2011-03-13 20:40:18');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(134, 0, 3, 4, 125, '2011-03-13 20:41:09');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(135, 0, 3, 4, 126, '2011-03-13 20:41:27');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(136, 0, 3, 4, 127, '2011-03-13 22:14:06');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(137, 0, 3, 4, 128, '2011-03-13 22:14:49');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(138, 0, 3, 4, 129, '2011-03-13 22:17:28');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(139, 0, 3, 4, 130, '2011-03-13 22:18:15');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(140, 0, 3, 4, 131, '2011-03-13 22:19:06');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(141, 0, 3, 4, 132, '2011-03-13 22:19:17');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(142, 0, 3, 4, 133, '2011-03-13 22:39:18');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(143, 0, 3, 4, 134, '2011-03-13 22:39:45');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(144, 0, 3, 4, 135, '2011-03-13 22:40:10');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(145, 0, 3, 4, 136, '2011-03-13 22:40:44');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(146, 0, 3, 4, 137, '2011-03-13 22:41:18');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(147, 0, 3, 4, 138, '2011-03-13 22:43:04');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(148, 0, 3, 4, 139, '2011-03-13 22:43:26');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(149, 0, 3, 4, 140, '2011-03-13 22:43:36');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(150, 0, 3, 4, 141, '2011-03-13 22:43:57');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(151, 0, 3, 4, 142, '2011-03-13 22:44:13');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(152, 0, 3, 4, 143, '2011-03-13 22:44:21');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(153, 0, 3, 4, 144, '2011-03-13 22:44:41');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(154, 0, 3, 4, 145, '2011-03-13 22:44:52');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(155, 0, 3, 4, 146, '2011-03-13 22:53:38');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(156, 0, 3, 4, 147, '2011-03-13 22:54:19');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(157, 0, 3, 4, 148, '2011-03-13 22:54:57');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(158, 0, 3, 4, 149, '2011-03-13 22:59:14');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(159, 0, 3, 4, 150, '2011-03-13 22:59:45');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(160, 0, 3, 4, 151, '2011-03-13 22:59:46');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(161, 0, 3, 4, 152, '2011-03-13 23:00:15');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(163, 0, 6, 0, 157, '2011-03-14 21:03:39');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(164, 0, 6, 0, 158, '2011-03-14 21:05:40');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(165, 0, 6, 0, 159, '2011-03-14 21:07:26');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(174, 0, 6, 7, 164, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(173, 0, 6, 7, 163, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(180, 0, 6, 9, 170, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(175, 0, 6, 8, 165, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(181, 0, 6, 9, 171, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(166, 0, 6, 7, 160, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(182, 0, 6, 10, 172, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(183, 0, 6, 10, 173, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(184, 0, 6, 10, 174, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(185, 0, 6, 10, 175, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(187, 0, 6, 11, 177, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(188, 0, 6, 11, 178, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(189, 0, 6, 12, 179, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(190, 0, 6, 12, 180, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(191, 0, 6, 12, 181, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(186, 0, 6, 10, 176, '2011-03-14 21:12:34');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(194, 0, 6, 7, 184, '2011-03-16 12:51:30');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(195, 0, 6, 7, 185, '2011-03-16 12:56:13');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(196, 0, 6, 9, 187, '2011-03-16 12:57:22');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(197, 0, 6, 7, 188, '2011-03-16 16:59:26');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(198, 0, 6, 7, 189, '2011-03-16 17:00:14');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(199, 1, 4, 1, 184, '2011-03-17 16:27:43');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(202, 1, 4, 1, 181, '2011-03-17 16:27:44');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(203, 1, 4, 1, 180, '2011-03-17 16:27:53');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(205, 0, 6, 7, 190, '2011-03-18 10:15:33');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(209, 1, 6, 1, 11, '2011-03-18 19:00:30');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(213, 1, 6, NULL, 4, '2011-03-26 09:19:43');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(214, 1, 6, NULL, 6, '2011-03-26 09:21:00');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(215, 1, 6, NULL, 7, '2011-03-26 09:21:24');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(216, 1, 6, NULL, 9, '2011-03-26 09:22:03');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(217, 1, 6, NULL, 22, '2011-03-26 09:24:01');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(218, 1, 6, NULL, 90, '2011-03-26 09:24:11');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(219, 1, 6, NULL, 97, '2011-03-26 09:24:14');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(231, 1, 6, NULL, 126, '2011-03-26 09:58:51');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(232, 1, 6, NULL, 127, '2011-03-26 09:59:37');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(233, 1, 6, NULL, 128, '2011-03-26 09:59:39');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(223, 1, 6, NULL, 147, '2011-03-26 09:30:11');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(224, 1, 6, NULL, 148, '2011-03-26 09:30:13');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(225, 1, 6, NULL, 149, '2011-03-26 09:30:15');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(226, 1, 6, NULL, 150, '2011-03-26 09:30:16');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(227, 1, 6, NULL, 151, '2011-03-26 09:30:18');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(228, 1, 6, NULL, 152, '2011-03-26 09:30:21');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(229, 1, 6, NULL, 143, '2011-03-26 09:30:25');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(234, 1, 6, NULL, 129, '2011-03-26 09:59:44');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(235, 1, 6, NULL, 130, '2011-03-26 09:59:52');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(236, 1, 6, NULL, 132, '2011-03-26 10:00:27');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(237, 1, 6, NULL, 133, '2011-03-26 10:00:29');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(238, 1, 6, NULL, 134, '2011-03-26 10:00:31');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(239, 1, 6, NULL, 123, '2011-03-26 10:00:42');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(240, 1, 6, NULL, 124, '2011-03-26 10:00:43');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(241, 1, 3, NULL, 190, '2011-03-26 11:43:58');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(242, 1, 3, NULL, 189, '2011-03-26 11:44:03');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(243, 1, 3, NULL, 188, '2011-03-26 11:44:07');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(244, 1, 3, NULL, 187, '2011-03-26 11:44:11');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(245, 1, 3, NULL, 185, '2011-03-26 11:44:14');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(247, 1, 1, NULL, 165, '2011-03-26 11:44:58');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(249, 1, 1, NULL, 170, '2011-03-26 11:45:00');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(252, 1, 1, NULL, 163, '2011-03-26 11:45:09');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(253, 1, 1, NULL, 164, '2011-03-26 11:45:11');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(257, 1, 3, NULL, 165, '2011-03-26 11:45:33');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(259, 1, 3, NULL, 170, '2011-03-26 11:45:36');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(263, 1, 3, NULL, 163, '2011-03-26 11:45:43');
INSERT INTO `posts_users` (`id`, `repost`, `user_id`, `topic_id`, `post_id`, `created`) VALUES(264, 1, 3, NULL, 164, '2011-03-26 11:45:44');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `routes`
--

DROP TABLE IF EXISTS `routes`;
CREATE TABLE `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_id` int(11) NOT NULL,
  `source` varchar(255) NOT NULL,
  `target_controller` varchar(100) NOT NULL,
  `target_action` varchar(100) NOT NULL,
  `target_param` varchar(20) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=77 ;

--
-- Daten für Tabelle `routes`
--

INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(1, 0, 'alf', 'users', 'view', '1', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(2, 1, 'alfs paper', 'papers', 'view', '1', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(3, 2, 'second paper', 'papers', 'view', '2', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(4, 0, 'ssecond post', 'posts', 'view', '1', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(5, 0, 'freitaggggggggg_erstessssssssss', 'posts', 'view', '2', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(6, 0, 'freitaggggggggg_zzzzzzzzzzzweitessssssss', 'posts', 'view', '3', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(7, 0, 'after save tset', 'posts', 'view', '48', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(8, 0, 'after save tset', 'posts', 'view', '49', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(9, 0, 'after save tset', 'posts', 'view', '55', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(10, 0, 'after save tset', 'posts', 'view', '56', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(11, 0, 'after save tset', 'posts', 'view', '57', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(12, 0, 'after save tset', 'posts', 'view', '58', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(13, 0, 'after save tset', 'posts', 'view', '59', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(14, 0, 'after save tset', 'posts', 'view', '60', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(15, 0, 'after save tset', 'posts', 'view', '61', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(16, 0, 'after save tset', 'posts', 'view', '62', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(17, 0, 'after save tset', 'posts', 'view', '63', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(18, 0, 'after save tset', 'posts', 'view', '64', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(19, 0, 'after save tset', 'posts', 'view', '65', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(20, 0, 'after save tset', 'posts', 'view', '69', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(21, 0, 'after save tset', 'posts', 'view', '70', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(22, 0, 'after save tset', 'posts', 'view', '71', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(23, 0, 'alf2', 'users', 'view', '2', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(24, 0, 'alf2', 'users', 'view', '3', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(25, 0, 'rr', 'posts', 'view', '82', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(26, 0, 'rr', 'posts', 'view', '83', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(27, 0, 'joggen', 'posts', 'view', '84', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(28, 0, 'fffffffff', 'posts', 'view', '85', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(29, 0, 'tim2', 'users', 'view', '4', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(30, 0, 'bla1', 'users', 'view', '5', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(31, 0, 'pansen', 'posts', 'view', '113', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(32, 0, 'bla', 'posts', 'view', '114', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(33, 0, 'kein repost hier -echter post', 'posts', 'view', '115', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(34, 0, 'bla', 'posts', 'view', '117', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(35, 0, 'test ', 'posts', 'view', '118', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(36, 0, 'geilo', 'posts', 'view', '119', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(37, 0, 'asdf', 'posts', 'view', '120', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(38, 0, 'asdf', 'posts', 'view', '121', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(39, 0, 'asdf', 'posts', 'view', '122', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(40, 0, 'asdf', 'posts', 'view', '123', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(41, 0, 'asdf', 'posts', 'view', '124', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(42, 0, 'asdf', 'posts', 'view', '125', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(43, 0, 'asdf', 'posts', 'view', '126', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(44, 0, 'dff img', 'posts', 'view', '127', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(45, 0, 'adsf', 'posts', 'view', '128', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(46, 0, 'asdf', 'posts', 'view', '129', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(47, 0, 'asdf', 'posts', 'view', '130', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(48, 0, 'asdf', 'posts', 'view', '131', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(49, 0, 'asdf', 'posts', 'view', '132', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(50, 0, 'asdf', 'posts', 'view', '133', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(51, 0, 'asdf', 'posts', 'view', '134', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(52, 0, 'asdf', 'posts', 'view', '135', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(53, 0, 'asdf', 'posts', 'view', '136', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(54, 0, 'asdf', 'posts', 'view', '137', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(55, 0, 'asdf', 'posts', 'view', '138', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(56, 0, 'asdf', 'posts', 'view', '139', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(57, 0, 'asdf', 'posts', 'view', '140', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(58, 0, 'asdf', 'posts', 'view', '141', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(59, 0, 'asdf', 'posts', 'view', '142', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(60, 0, 'asdf', 'posts', 'view', '143', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(61, 0, 'asdf', 'posts', 'view', '144', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(62, 0, 'asdf', 'posts', 'view', '145', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(63, 0, 'asdf', 'posts', 'view', '146', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(64, 0, 'asdf', 'posts', 'view', '147', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(65, 0, 'asdf', 'posts', 'view', '148', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(66, 0, 'asdf', 'posts', 'view', '149', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(67, 0, 'asdf', 'posts', 'view', '150', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(68, 0, 'asdf', 'posts', 'view', '151', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(69, 0, 'asdf', 'posts', 'view', '152', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(70, 0, 'tim', 'users', 'view', '6', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(71, 0, 'hans', 'users', 'view', '7', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(72, 9, 'pansen', 'papers', 'view', '9', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(73, 10, 'test', 'papers', 'view', '10', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(74, 13, 'test2', 'papers', 'view', '13', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(75, 14, 'test', 'papers', 'view', '14', 0);
INSERT INTO `routes` (`id`, `ref_id`, `source`, `target_controller`, `target_action`, `target_param`, `parent_id`) VALUES(76, 15, 'donnerstag', 'papers', 'view', '15', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
CREATE TABLE `schema_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Daten für Tabelle `schema_migrations`
--

INSERT INTO `schema_migrations` (`id`, `version`, `type`, `created`) VALUES(1, 1, 'migrations', '2011-02-14 22:27:54');
INSERT INTO `schema_migrations` (`id`, `version`, `type`, `created`) VALUES(4, 1, 'app', '2011-02-14 22:39:54');
INSERT INTO `schema_migrations` (`id`, `version`, `type`, `created`) VALUES(5, 4, 'app', '2011-02-14 22:46:34');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `own_paper` tinyint(6) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Daten für Tabelle `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(1, 1, 0, 0, '2011-03-18 18:02:48', '2011-03-18 18:02:48');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(2, 1, 0, 0, '2011-03-18 18:03:14', '2011-03-18 18:03:14');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(5, 10, 6, 0, '2011-03-18 18:18:02', '2011-03-18 18:18:02');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(13, 1, 3, 0, '2011-03-18 19:53:48', '2011-03-18 19:53:48');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(20, 15, 6, 0, '2011-03-24 21:26:24', '2011-03-24 21:26:24');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(10, 1, 4, 0, '2011-03-18 19:08:10', '2011-03-18 19:08:10');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(11, 5, 4, 0, '2011-03-18 19:08:53', '2011-03-18 19:08:53');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(12, 6, 4, 0, '2011-03-18 19:09:49', '2011-03-18 19:09:49');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(14, 13, 6, 1, '2011-03-24 17:18:08', '2011-03-24 17:18:08');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(15, 14, 6, 1, '2011-03-24 17:18:46', '2011-03-24 17:18:46');
INSERT INTO `subscriptions` (`id`, `paper_id`, `user_id`, `own_paper`, `created`, `modified`) VALUES(19, 15, 1, 1, '2011-03-24 21:13:05', '2011-03-24 21:13:05');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `test`
--

DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `test` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `test`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `topics`
--

DROP TABLE IF EXISTS `topics`;
CREATE TABLE `topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `enabled` int(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Daten für Tabelle `topics`
--

INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(1, 'test_topi', 1, '2011-02-15 22:19:57', '2011-02-15 22:19:57', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(2, 'second topoic', 1, '2011-02-16 19:47:16', '2011-02-16 19:47:16', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(3, 'test_topi', 2, '2011-02-24 23:44:52', '2011-02-24 23:44:52', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(4, 'test_topi', 3, '2011-02-24 23:46:52', '2011-02-24 23:46:52', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(5, 'first_automatic_topic', 4, '2011-03-02 16:56:35', '2011-03-02 16:56:35', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(6, 'first_automatic_topic', 5, '2011-03-02 16:57:58', '2011-03-02 16:57:58', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(7, 'pansen', 6, '2011-03-14 21:12:05', '2011-03-14 21:12:05', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(8, 'tim1', 6, '2011-03-15 11:52:57', '2011-03-15 11:52:57', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(9, 'tim2', 6, '2011-03-15 11:53:00', '2011-03-15 11:53:00', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(10, 'tim3', 6, '2011-03-15 11:53:03', '2011-03-15 11:53:03', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(11, 'tim4', 6, '2011-03-15 11:53:08', '2011-03-15 11:53:08', 1);
INSERT INTO `topics` (`id`, `name`, `user_id`, `created`, `modified`, `enabled`) VALUES(12, 'tim5', 6, '2011-03-15 11:53:10', '2011-03-15 11:53:10', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `firstname` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `count_posts_reposts` int(11) NOT NULL DEFAULT '0',
  `count_reposts` int(11) NOT NULL DEFAULT '0',
  `count_comments` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`id`, `group_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`, `count_posts_reposts`, `count_reposts`, `count_comments`) VALUES(1, 1, 'alf', 'alf', 'alf@alf.de', 'alf', '94afe8c425aec767e47fd14e547fcffb796e66a2', '2011-02-15 22:19:57', '2011-02-15 22:19:57', NULL, 1, 23, 4, 0);
INSERT INTO `users` (`id`, `group_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`, `count_posts_reposts`, `count_reposts`, `count_comments`) VALUES(3, 1, 'seb', 'alfers', 'alf2@alf2.de', 'alf2', '5072f955ef5abb2c34a88a683fb072ce3862d072', '2011-02-24 23:46:52', '2011-02-24 23:46:52', NULL, 1, 79, 41, 0);
INSERT INTO `users` (`id`, `group_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`, `count_posts_reposts`, `count_reposts`, `count_comments`) VALUES(4, 1, '', '', 'timmie@t.de', 'tim2', '1cde3eecf706ae48234724f993d6aad6ceab716e', '2011-03-02 16:56:34', '2011-03-02 16:56:35', NULL, 1, 2, 9, 0);
INSERT INTO `users` (`id`, `group_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`, `count_posts_reposts`, `count_reposts`, `count_comments`) VALUES(5, 1, 'bla', 'bla', 'tim@tim.de', 'bla1', '39139523b4e1c3e2983caf09355a83b1c512083c', '2011-03-02 16:57:58', '2011-03-02 16:57:58', NULL, 1, 0, 0, 0);
INSERT INTO `users` (`id`, `group_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`, `count_posts_reposts`, `count_reposts`, `count_comments`) VALUES(6, 1, '', '', 'tim@tim.de', 'tim', '89fc872d377a62ba2e75bbd1d630eb790ee687f9', '2011-03-14 20:48:17', '2011-03-14 20:48:17', NULL, 1, 50, 24, 10);
INSERT INTO `users` (`id`, `group_id`, `firstname`, `name`, `email`, `username`, `password`, `created`, `modified`, `lastlogin`, `enabled`, `count_posts_reposts`, `count_reposts`, `count_comments`) VALUES(7, 1, '', '', 'hans@hans.de', 'hans', 'f10e739b1acbbd77a09d8d06454eaeb59b5c8389', '2011-03-16 13:18:54', '2011-03-16 13:18:54', NULL, 1, 0, 0, 0);
